import React from 'react';
import { TeamMemberSkillStat, SkillNode } from '../../types/lxp';
import {
  BarChart3,
  TrendingUp,
  AlertCircle,
  Users,
  Award,
  Zap,
  DollarSign,
  ShieldAlert,
  ArrowUpRight,
  CheckCircle,
  Clock
} from 'lucide-react';

interface EnterpriseAnalyticsProps {
  teamStats: TeamMemberSkillStat[];
  skills: SkillNode[];
}

export const EnterpriseAnalytics: React.FC<EnterpriseAnalyticsProps> = ({
  teamStats,
  skills,
}) => {
  // Aggregate KPIs
  const totalEngineers = teamStats.length;
  const avgReadiness = Math.round(
    teamStats.reduce((acc, m) => acc + m.readinessPercentage, 0) / totalEngineers
  );
  const totalWeeklyHours = teamStats.reduce((acc, m) => acc + m.weeklyHours, 0);

  // Simulated organizational ROI
  const estimatedSavings = Math.round(totalWeeklyHours * 160 * 4.2); // based on $160/hr contractor replacement value

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded-2xl border border-slate-800 bg-gradient-to-r from-slate-900 via-emerald-950/20 to-slate-900 p-6 backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded-md bg-emerald-500/10 px-2.5 py-1 text-xs font-semibold text-emerald-400 border border-emerald-500/20">
                Enterprise L&D & Engineering Studio
              </span>
              <span className="text-xs text-slate-400">Team Skill Coverage & Velocity</span>
            </div>
            <h1 className="mt-2 text-2xl font-bold tracking-tight text-white">
              Engineering Capability Intelligence & Talent Mobility
            </h1>
            <p className="mt-1 text-xs text-slate-300 max-w-2xl">
              Real-time analytics replacing legacy LMS course completion checkboxes with verifiable, production-tested skill competencies.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3.5 py-2 text-xs font-bold text-emerald-300 flex items-center gap-1.5">
              <DollarSign className="h-4 w-4" />
              <span>Est. Internal Upskilling ROI: ${estimatedSavings.toLocaleString()}</span>
            </span>
          </div>
        </div>

        {/* Executive KPI Row */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4 border-t border-slate-800 pt-4">
          <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-3.5">
            <div className="text-[11px] font-medium text-slate-400">Team Benchmark Readiness</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-bold text-white">{avgReadiness}%</span>
              <span className="text-xs text-emerald-400 font-semibold flex items-center">
                <TrendingUp className="h-3 w-3 inline mr-0.5" /> +12% this qtr
              </span>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-3.5">
            <div className="text-[11px] font-medium text-slate-400">Weekly Learning Velocity</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-bold text-cyan-400">{totalWeeklyHours.toFixed(1)}h</span>
              <span className="text-xs text-slate-400">across {totalEngineers} engineers</span>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-3.5">
            <div className="text-[11px] font-medium text-slate-400">Active Peer Reviews</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-bold text-indigo-400">18</span>
              <span className="text-xs text-slate-400">completed RFCs</span>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-3.5">
            <div className="text-[11px] font-medium text-slate-400">Critical Skill Debt</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-bold text-rose-400">2 Areas</span>
              <span className="text-xs text-rose-400/80">LLM Security, Chaos Eng</span>
            </div>
          </div>
        </div>
      </div>

      {/* Critical Competency Debt Warning Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-rose-500/30 bg-rose-950/10 p-5 flex items-start gap-3.5">
          <ShieldAlert className="h-6 w-6 text-rose-400 flex-shrink-0 mt-0.5" />
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white">Competency Debt Alert: LLM Red Teaming & Guardrails</h3>
              <span className="rounded bg-rose-500/20 px-2 py-0.5 text-[10px] font-bold text-rose-300">High Risk</span>
            </div>
            <p className="mt-1 text-xs text-slate-300 leading-relaxed">
              3 roadmap initiatives rely on AI security compliance for upcoming SOC2 Type II audit, but only 1 of 4 team members has verified proficiency.
            </p>
            <p className="mt-2 text-xs font-semibold text-rose-300">
              Recommended Action: Auto-enroll cohort in Milestone 3 of Enterprise AI Architect.
            </p>
          </div>
        </div>

        <div className="rounded-2xl border border-amber-500/30 bg-amber-950/10 p-5 flex items-start gap-3.5">
          <AlertCircle className="h-6 w-6 text-amber-400 flex-shrink-0 mt-0.5" />
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white">Emerging Capability: Multi-Agent State Machine Routing</h3>
              <span className="rounded bg-amber-500/20 px-2 py-0.5 text-[10px] font-bold text-amber-300">Fast Growing</span>
            </div>
            <p className="mt-1 text-xs text-slate-300 leading-relaxed">
              Team engagement in LangGraph and AutoGen scenario labs has spiked +140% in the last 14 days. Velocity is ahead of enterprise targets.
            </p>
            <p className="mt-2 text-xs font-semibold text-amber-300">
              Opportunity: Schedule internal brown-bag showcase on Friday.
            </p>
          </div>
        </div>
      </div>

      {/* Team Member Skill Benchmark Leaderboard */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 backdrop-blur-md">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white">Engineering Cohort Readiness Matrix</h3>
            <p className="text-xs text-slate-400">
              Target role readiness calculated from verified lab evaluations, peer reviews, and diagnostics.
            </p>
          </div>
        </div>

        <div className="mt-4 divide-y divide-slate-800">
          {teamStats.map((member) => (
            <div key={member.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src={member.avatar}
                  alt={member.name}
                  className="h-10 w-10 rounded-full object-cover ring-2 ring-slate-700"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white">{member.name}</span>
                    <span className="text-[10px] font-semibold text-slate-400">({member.role})</span>
                  </div>
                  <p className="text-xs text-indigo-400">
                    Target: <strong className="text-slate-200">{member.targetRole}</strong>
                  </p>
                </div>
              </div>

              {/* Top Skills Badges */}
              <div className="flex flex-wrap items-center gap-1.5">
                {member.topSkills.map((sk, idx) => (
                  <span
                    key={idx}
                    className="rounded-lg bg-slate-950 px-2.5 py-1 text-[11px] font-medium text-slate-300 border border-slate-800"
                  >
                    {sk.name} <strong className="text-indigo-400 font-bold ml-1">L{sk.level}</strong>
                  </span>
                ))}
              </div>

              {/* Readiness Progress Bar & Hours */}
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-xs font-bold text-white">{member.readinessPercentage}% Ready</div>
                  <div className="text-[10px] text-slate-400">{member.weeklyHours} hrs this week</div>
                </div>

                <div className="w-24 h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      member.status === 'ahead'
                        ? 'bg-emerald-500'
                        : member.status === 'on_track'
                        ? 'bg-indigo-500'
                        : 'bg-amber-500'
                    }`}
                    style={{ width: `${member.readinessPercentage}%` }}
                  />
                </div>

                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                  member.status === 'ahead'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    : member.status === 'on_track'
                    ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                    : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                }`}>
                  {member.status === 'ahead' ? 'Ahead' : member.status === 'on_track' ? 'On Track' : 'Needs Focus'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
