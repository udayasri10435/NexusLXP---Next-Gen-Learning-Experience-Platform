import React, { useState } from 'react';
import {
  CohortPod,
  PeerByte,
  PeerReviewSubmission,
  DiscussionThread
} from '../../types/lxp';
import {
  Users,
  MessageSquare,
  Sparkles,
  Heart,
  Calendar,
  Share2,
  Send,
  Plus,
  ExternalLink,
  CheckCircle,
  FileCheck,
  Bookmark,
  Award,
  Filter,
  Check
} from 'lucide-react';

interface SocialHubProps {
  cohorts: CohortPod[];
  peerBytes: PeerByte[];
  peerReviews: PeerReviewSubmission[];
  discussions: DiscussionThread[];
  onToggleCohortJoin: (cohortId: string) => void;
  onLikeByte: (byteId: string) => void;
  onAddByte: (title: string, snippet: string, tag: string) => void;
  onSubmitReviewFeedback: (reviewId: string, feedback: string) => void;
}

export const SocialHub: React.FC<SocialHubProps> = ({
  cohorts,
  peerBytes,
  peerReviews,
  discussions,
  onToggleCohortJoin,
  onLikeByte,
  onAddByte,
  onSubmitReviewFeedback,
}) => {
  const [subTab, setSubTab] = useState<'bytes' | 'cohorts' | 'reviews' | 'discussions'>('bytes');
  const [isPostingByte, setIsPostingByte] = useState(false);
  const [newByteTitle, setNewByteTitle] = useState('');
  const [newByteSnippet, setNewByteSnippet] = useState('');
  const [newByteTag, setNewByteTag] = useState('ProductionAI');

  // Review modal / feedback state
  const [selectedReviewForFeedback, setSelectedReviewForFeedback] = useState<PeerReviewSubmission | null>(null);
  const [feedbackText, setFeedbackText] = useState('');

  const handlePostByteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newByteTitle.trim() || !newByteSnippet.trim()) return;
    onAddByte(newByteTitle, newByteSnippet, newByteTag);
    setNewByteTitle('');
    setNewByteSnippet('');
    setIsPostingByte(false);
  };

  const handleSendFeedback = () => {
    if (!selectedReviewForFeedback || !feedbackText.trim()) return;
    onSubmitReviewFeedback(selectedReviewForFeedback.id, feedbackText);
    setSelectedReviewForFeedback(null);
    setFeedbackText('');
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-2xl border border-slate-800 bg-gradient-to-r from-slate-900 via-indigo-950/30 to-slate-900 p-6 backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded-md bg-purple-500/10 px-2.5 py-1 text-xs font-semibold text-purple-400 border border-purple-500/20">
                Social Learning & Cohorts
              </span>
              <span className="text-xs text-slate-400">Peer-Powered Knowledge Sharing</span>
            </div>
            <h1 className="mt-2 text-2xl font-bold tracking-tight text-white">
              Collaborative Pods & Peer Knowledge Exchange
            </h1>
            <p className="mt-1 text-xs text-slate-300 max-w-2xl">
              Research shows peer-led cohort discussions and architecture critiques accelerate time-to-competence by 3.4x over isolated passive learning.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPostingByte(true)}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:from-indigo-500 hover:to-violet-500 transition-all"
            >
              <Sparkles className="h-4 w-4 text-amber-300" />
              <span>Share Knowledge Byte</span>
            </button>
          </div>
        </div>

        {/* Sub-navigation tabs */}
        <div className="mt-6 flex flex-wrap items-center gap-2 border-t border-slate-800 pt-4">
          <button
            onClick={() => setSubTab('bytes')}
            className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'bytes'
                ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40'
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Sparkles className="h-3.5 w-3.5 text-amber-400" />
            <span>Peer Bytes ({peerBytes.length})</span>
          </button>

          <button
            onClick={() => setSubTab('cohorts')}
            className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'cohorts'
                ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40'
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Users className="h-3.5 w-3.5 text-cyan-400" />
            <span>Active Study Pods ({cohorts.length})</span>
          </button>

          <button
            onClick={() => setSubTab('reviews')}
            className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'reviews'
                ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40'
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <FileCheck className="h-3.5 w-3.5 text-emerald-400" />
            <span>Peer Review Arena ({peerReviews.length})</span>
          </button>

          <button
            onClick={() => setSubTab('discussions')}
            className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'discussions'
                ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40'
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <MessageSquare className="h-3.5 w-3.5 text-purple-400" />
            <span>Architecture Debates ({discussions.length})</span>
          </button>
        </div>
      </div>

      {/* SUBTAB 1: Peer Bytes (Microlearning Insights) */}
      {subTab === 'bytes' && (
        <div className="space-y-4">
          {/* Post a Byte Modal / Form */}
          {isPostingByte && (
            <form
              onSubmit={handlePostByteSubmit}
              className="rounded-2xl border border-indigo-500/40 bg-slate-900/90 p-5 backdrop-blur-md shadow-xl animate-in fade-in"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-amber-400" />
                  <span>Share an Architectural Byte with Peers</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setIsPostingByte(false)}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
              </div>

              <div className="mt-4 space-y-3">
                <input
                  type="text"
                  placeholder="Catchy Takeaway (e.g. Why we shifted from Rerankers to Contextual BM25)"
                  value={newByteTitle}
                  onChange={(e) => setNewByteTitle(e.target.value)}
                  className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
                  required
                />

                <textarea
                  placeholder="Share the concrete engineering finding, metric comparison, or hard-won lesson..."
                  value={newByteSnippet}
                  onChange={(e) => setNewByteSnippet(e.target.value)}
                  rows={3}
                  className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
                  required
                />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <span>Tag:</span>
                    <select
                      value={newByteTag}
                      onChange={(e) => setNewByteTag(e.target.value)}
                      className="rounded border border-slate-800 bg-slate-950 px-2 py-1 text-xs text-slate-200"
                    >
                      <option value="ProductionAI">#ProductionAI</option>
                      <option value="DistributedSystems">#DistributedSystems</option>
                      <option value="Leadership">#Leadership</option>
                      <option value="Observability">#Observability</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-4 py-1.5 text-xs font-bold text-white hover:bg-indigo-500 shadow-md"
                  >
                    <Send className="h-3 w-3" />
                    <span>Publish Byte</span>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* Bytes Feed */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {peerBytes.map((byte) => (
              <div
                key={byte.id}
                className="group relative flex flex-col justify-between rounded-2xl border border-slate-800 bg-slate-900/60 p-5 hover:border-slate-700 hover:bg-slate-900 transition-all duration-200 backdrop-blur-sm"
              >
                <div>
                  {/* Author Header */}
                  <div className="flex items-center gap-3">
                    <img
                      src={byte.author.avatar}
                      alt={byte.author.name}
                      className="h-10 w-10 rounded-full object-cover ring-2 ring-indigo-500/30"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white truncate">
                          {byte.author.name}
                        </span>
                        <span className="rounded bg-indigo-500/10 px-1.5 py-0.2 text-[9px] font-semibold text-indigo-400 border border-indigo-500/20">
                          {byte.author.badge}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 truncate">{byte.author.role}</p>
                    </div>
                  </div>

                  {/* Byte Title & Content */}
                  <h3 className="mt-3.5 text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                    {byte.title}
                  </h3>

                  <p className="mt-2 text-xs leading-relaxed text-slate-300 line-clamp-4">
                    "{byte.snippet}"
                  </p>

                  {/* Tags */}
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {byte.tags.map((tag) => (
                      <span
                        key={tag}
                        className="rounded-md bg-slate-800/80 px-2 py-0.5 text-[10px] font-medium text-slate-400 border border-slate-700/50"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Footer Controls */}
                <div className="mt-4 flex items-center justify-between border-t border-slate-800/80 pt-3 text-xs text-slate-400">
                  <span className="text-[11px] text-slate-500">{byte.timestamp}</span>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onLikeByte(byte.id)}
                      className={`flex items-center gap-1.5 text-xs transition-colors ${
                        byte.hasLiked ? 'text-rose-400 font-bold' : 'text-slate-400 hover:text-rose-400'
                      }`}
                    >
                      <Heart className={`h-3.5 w-3.5 ${byte.hasLiked ? 'fill-rose-400' : ''}`} />
                      <span>{byte.likes}</span>
                    </button>

                    <div className="flex items-center gap-1 text-slate-400">
                      <MessageSquare className="h-3.5 w-3.5 text-slate-500" />
                      <span>{byte.commentsCount}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 2: Cohort Study Pods */}
      {subTab === 'cohorts' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {cohorts.map((cohort) => (
            <div
              key={cohort.id}
              className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 flex flex-col justify-between backdrop-blur-sm"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-cyan-500/10 px-2.5 py-1 text-xs font-semibold text-cyan-400 border border-cyan-500/20">
                    Active Study Circle
                  </span>
                  <span className="text-xs text-slate-400">
                    {cohort.activeLearners} / {cohort.maxCapacity} Seats Filled
                  </span>
                </div>

                <h3 className="mt-3 text-base font-bold text-white">
                  {cohort.name}
                </h3>
                <p className="mt-1 text-xs text-slate-400">
                  Topic: <strong className="text-slate-200">{cohort.topic}</strong>
                </p>

                {/* Milestone Progress in Cohort */}
                <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/70 p-3">
                  <span className="text-[11px] font-medium text-slate-400 block mb-1">Current Sprint Focus:</span>
                  <p className="text-xs font-semibold text-indigo-300">{cohort.currentMilestone}</p>
                </div>

                {/* Facilitator & Next Sync */}
                <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <img
                      src={cohort.facilitator.avatar}
                      alt={cohort.facilitator.name}
                      className="h-8 w-8 rounded-full object-cover ring-1 ring-slate-700"
                    />
                    <div>
                      <p className="font-semibold text-white truncate">{cohort.facilitator.name}</p>
                      <p className="text-[10px] text-slate-400">{cohort.facilitator.role}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 rounded-lg bg-slate-800/40 px-2 py-1">
                    <Calendar className="h-4 w-4 text-cyan-400 flex-shrink-0" />
                    <div>
                      <p className="text-[10px] text-slate-400">Next Live Sync:</p>
                      <p className="text-[11px] font-medium text-slate-200">{cohort.nextSyncDate}</p>
                    </div>
                  </div>
                </div>

                {/* Member avatars */}
                <div className="mt-4 flex items-center gap-2">
                  <div className="flex -space-x-2">
                    {cohort.memberAvatars.map((av, idx) => (
                      <img
                        key={idx}
                        src={av}
                        alt="Cohort member"
                        className="h-7 w-7 rounded-full border-2 border-slate-900 object-cover"
                      />
                    ))}
                  </div>
                  <span className="text-[11px] text-slate-400">
                    +{cohort.activeLearners - cohort.memberAvatars.length} other engineers
                  </span>
                </div>
              </div>

              {/* Action Button */}
              <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
                <button
                  onClick={() => onToggleCohortJoin(cohort.id)}
                  className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition-all ${
                    cohort.joined
                      ? 'border border-emerald-500/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20'
                      : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-lg shadow-indigo-600/30'
                  }`}
                >
                  {cohort.joined ? (
                    <>
                      <Check className="h-3.5 w-3.5" />
                      <span>Cohort Joined (Access Slack & Syncs)</span>
                    </>
                  ) : (
                    <>
                      <Users className="h-3.5 w-3.5" />
                      <span>Join Study Pod</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUBTAB 3: Peer Review Arena */}
      {subTab === 'reviews' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-xs text-slate-400">
              Review 2 cohort peer deliverables to unlock your own verified credential badge.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {peerReviews.map((pr) => (
              <div
                key={pr.id}
                className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 flex flex-col justify-between backdrop-blur-sm"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={pr.studentAvatar}
                        alt={pr.studentName}
                        className="h-8 w-8 rounded-full object-cover ring-1 ring-slate-700"
                      />
                      <div>
                        <p className="text-xs font-bold text-white">{pr.studentName}</p>
                        <p className="text-[10px] text-slate-400">{pr.submittedAt} in {pr.pathName}</p>
                      </div>
                    </div>

                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                      pr.status === 'reviewed'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    }`}>
                      {pr.status === 'reviewed' ? `Reviewed (${pr.rubricScore}/100)` : 'Needs Peer Review'}
                    </span>
                  </div>

                  <h3 className="mt-3 text-sm font-bold text-white">
                    {pr.projectTitle}
                  </h3>
                  <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                    {pr.description}
                  </p>

                  <div className="mt-3">
                    <a
                      href={pr.repoOrDocUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-400 hover:text-indigo-300 underline"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      <span>View Project Architecture RFC Repository</span>
                    </a>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400">
                    {pr.reviewsCount} of {pr.reviewsNeeded} reviews submitted
                  </span>

                  <button
                    onClick={() => setSelectedReviewForFeedback(pr)}
                    className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500"
                  >
                    <FileCheck className="h-3.5 w-3.5" />
                    <span>Submit Rubric Review</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Feedback Modal */}
          {selectedReviewForFeedback && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-md">
              <div className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
                <h3 className="text-base font-bold text-white">
                  Peer Review Rubric: {selectedReviewForFeedback.projectTitle}
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Evaluate design trade-offs, resilience under failure, and clarity.
                </p>

                <div className="mt-4 space-y-3">
                  <div className="rounded-lg bg-slate-950 p-3 text-xs text-slate-300">
                    <p className="font-semibold text-indigo-400 mb-1">Rubric Criteria:</p>
                    <ul className="list-disc pl-4 space-y-1 text-slate-400">
                      <li>Fault Tolerance & Blast Radius Containment</li>
                      <li>Latency, Concurrency, and Resource Optimization</li>
                      <li>Clarity of Non-Goals and Rollback Plan</li>
                    </ul>
                  </div>

                  <textarea
                    placeholder="Provide constructive feedback, edge cases you spotted, and recommendations..."
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                    rows={4}
                    className="w-full rounded-xl border border-slate-800 bg-slate-950 p-3 text-xs text-slate-200 placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="mt-4 flex justify-end gap-2">
                  <button
                    onClick={() => setSelectedReviewForFeedback(null)}
                    className="rounded-lg px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSendFeedback}
                    className="rounded-lg bg-indigo-600 px-4 py-1.5 text-xs font-bold text-white hover:bg-indigo-500"
                  >
                    Submit Review (+150 XP)
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 4: Architecture Debates & Discussions */}
      {subTab === 'discussions' && (
        <div className="space-y-4">
          {discussions.map((disc) => (
            <div
              key={disc.id}
              className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-4 backdrop-blur-sm"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <img
                    src={disc.author.avatar}
                    alt={disc.author.name}
                    className="h-9 w-9 rounded-full object-cover ring-1 ring-slate-700"
                  />
                  <div>
                    <p className="text-xs font-bold text-white">{disc.author.name}</p>
                    <p className="text-[10px] text-slate-400">{disc.author.role} • {disc.timestamp}</p>
                  </div>
                </div>

                <span className="rounded-md bg-slate-800 px-2.5 py-1 text-[11px] font-medium text-slate-300">
                  {disc.category}
                </span>
              </div>

              <div>
                <h3 className="text-sm font-bold text-white">{disc.title}</h3>
                <p className="mt-1 text-xs text-slate-300 leading-relaxed">{disc.body}</p>
              </div>

              {/* Replies */}
              <div className="space-y-2 border-t border-slate-800/80 pt-3">
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Community Answers ({disc.replies.length})
                </p>

                {disc.replies.map((rep) => (
                  <div
                    key={rep.id}
                    className={`rounded-xl border p-3 ${
                      rep.isAcceptedSolution
                        ? 'border-emerald-500/40 bg-emerald-950/20'
                        : 'border-slate-800 bg-slate-950/50'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <div className="flex items-center gap-2">
                        <img
                          src={rep.author.avatar}
                          alt={rep.author.name}
                          className="h-5 w-5 rounded-full object-cover"
                        />
                        <span className="font-semibold text-white">{rep.author.name}</span>
                        <span className="text-[10px] text-slate-500">{rep.timestamp}</span>
                      </div>

                      {rep.isAcceptedSolution && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                          <CheckCircle className="h-3 w-3" />
                          Accepted Solution
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed pl-7">{rep.content}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
