import React, { useState } from 'react';
import { SkillNode } from '../../types/lxp';
import { X, CheckCircle2, AlertCircle, Award, ArrowRight, Zap, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';

interface SkillDiagnosticModalProps {
  skill: SkillNode | null;
  isOpen: boolean;
  onClose: () => void;
  onLevelUp: (skillId: string, newLevel: number, earnedXp: number) => void;
}

interface DiagnosticQuestion {
  question: string;
  codeSnippet?: string;
  options: string[];
  correctIndex: number;
  rationale: string;
}

const SKILL_QUESTIONS_MAP: Record<string, DiagnosticQuestion[]> = {
  llm_agents: [
    {
      question: 'When implementing a stateful multi-agent system, what pattern prevents infinite loops when an agent experiences tool execution failure?',
      options: [
        'Increase LLM temperature to 1.5 to encourage creative recovery.',
        'Implement an explicit recursion limit, state checkpointing, and fallback human-in-the-loop intervention.',
        'Use larger context windows (128k tokens) so the agent can keep retrying.',
        'Disable structured output parsing.'
      ],
      correctIndex: 1,
      rationale: 'Without explicit recursion limits, deterministic cycle detection, and checkpoint rollback mechanisms, agents can enter destructive hallucination loops.'
    },
    {
      question: 'In the Plan-and-Solve agentic pattern, why is step decomposition separated from tool execution?',
      options: [
        'Because vector databases only accept 1 tool call per request.',
        'Decoupling global planning from atomic step execution reduces token drift and allows replanning when individual sub-goals fail.',
        'Plan-and-solve reduces latency by 90% compared to zero-shot prompting.',
        'It is required by OpenAPI schemas.'
      ],
      correctIndex: 1,
      rationale: 'Global planning establishes systemic context, while sub-agent executors focus only on local tool parameters, drastically improving convergence.'
    },
    {
      question: 'What is the primary role of "Memory Reflection" in agentic cognitive architectures like Reflexion?',
      options: [
        'Re-compiling Python scripts at runtime.',
        'Synthesizing verbal critique from past execution traces to store in episodic memory as future contextual cues.',
        'Deleting user session logs to ensure GDPR compliance.',
        'Encrypting API bearer tokens.'
      ],
      correctIndex: 1,
      rationale: 'Reflexion agents critique their own failure modes and persist reflective notes, dramatically boosting subsequent trial accuracy.'
    }
  ],
  rag_architectures: [
    {
      question: 'What is the core advantage of ColBERT late-interaction embeddings over standard dense bi-encoders (e.g. OpenAI text-embedding-3)?',
      options: [
        'ColBERT produces a single scalar number instead of a vector.',
        'ColBERT maintains token-level embeddings and computes maximum similarity per token (MaxSim), preserving fine-grained token-level nuances.',
        'ColBERT requires no indexing time or memory.',
        'ColBERT runs exclusively on mobile CPUs.'
      ],
      correctIndex: 1,
      rationale: 'Instead of compressing an entire document into a single vector (which loses token subtleties), ColBERT computes token-to-token MaxSim at query time with high efficiency.'
    },
    {
      question: 'When implementing Reciprocal Rank Fusion (RRF) between Dense vector search and BM25 sparse search, what does the constant k (typically 60) accomplish?',
      options: [
        'It sets the maximum number of documents returned.',
        'It smooths the impact of top-ranked items so single outliers do not disproportionately dominate the combined score.',
        'It converts cosine distance into Manhattan distance.',
        'It limits memory allocation to 60 megabytes.'
      ],
      correctIndex: 1,
      rationale: 'The constant k dampens the sharp decay between rank 1 and rank 2, ensuring balanced fusion without requiring score normalization.'
    },
    {
      question: 'What is the "Lost in the Middle" phenomenon in long-context retrieval and generation?',
      options: [
        'Network packets dropping in transit between server and client.',
        'LLMs attend strongly to facts located at the very start and end of retrieved context windows, frequently missing facts located in the central third.',
        'Vector indexes forgetting vectors inserted during mid-day batches.',
        'When an embedding model outputs zeroes for middle vector dimensions.'
      ],
      correctIndex: 1,
      rationale: 'Extensive empirical benchmarks demonstrate that transformer attention mechanisms suffer degraded recall on facts situated in the middle of dense prompts.'
    }
  ],
  distributed_systems: [
    {
      question: 'In the Raft consensus protocol, what happens when a follower server receives an AppendEntries RPC from a candidate with an older Term number?',
      options: [
        'The follower immediately abdicates and becomes a candidate.',
        'The follower rejects the RPC and returns its current higher Term.',
        'The follower merges both log streams together.',
        'The follower shuts down.'
      ],
      correctIndex: 1,
      rationale: 'Safety invariant: servers reject any request containing an obsolete term and provide their current term to force the stale candidate to step down.'
    },
    {
      question: 'How does consistent hashing prevent massive re-keying when a node joins or leaves a distributed cluster?',
      options: [
        'It maps both keys and nodes to an identical circular 360-degree hash ring, meaning only k/N keys migrate on membership changes.',
        'It duplicates the entire database on every single machine.',
        'It disables hash functions and uses sequential integer IDs.',
        'It forces all clients to connect to a single central load balancer.'
      ],
      correctIndex: 0,
      rationale: 'With consistent hashing, keys are assigned to the nearest clockwise node. Adding or removing a node affects only its immediate neighbors.'
    },
    {
      question: 'Under CAP theorem, during a network partition (P), why can a system NOT be simultaneously Available (A) and Consistent (C)?',
      options: [
        'Because hardware disks cannot write data when Ethernet cables disconnect.',
        'Because acknowledging a write in an isolated partition either risks serving stale data (violates C) or rejecting the write (violates A).',
        'Because SSL certificates expire when nodes cannot reach DNS.',
        'Because transactions cannot exceed 100 milliseconds.'
      ],
      correctIndex: 1,
      rationale: 'If nodes cannot communicate, you must choose: accept updates on both sides causing split-brain inconsistency, or reject writes to maintain consistency at the cost of availability.'
    }
  ]
};

// Generic fallback questions if skill isn't in dedicated map
const GENERIC_QUESTIONS: DiagnosticQuestion[] = [
  {
    question: 'In enterprise production engineering, what is the best practice for establishing fault tolerance across external third-party dependencies?',
    options: [
      'Increase timeout values to 60 seconds so calls never fail.',
      'Implement circuit breakers, exponential backoff with jitter, and graceful fallback defaults.',
      'Disable monitoring to avoid alert fatigue.',
      'Execute all requests synchronously in the main thread.'
    ],
    correctIndex: 1,
    rationale: 'Circuit breakers prevent cascading outages, while backoff with jitter avoids thundering herd problems during recovery.'
  },
  {
    question: 'When scaling systems horizontally, what architectural characteristic is essential for stateful components?',
    options: [
      'Store all session state in local in-memory singletons.',
      'Externalize state to dedicated distributed stores (Redis, DynamoDB, PostgreSQL) or implement distributed consensus.',
      'Rely on sticky sessions without database persistence.',
      'Prevent any autoscaling events.'
    ],
    correctIndex: 1,
    rationale: 'Stateless application tiers backed by distributed data engines allow elastic scaling without losing active customer sessions.'
  },
  {
    question: 'What is the primary indicator of architectural technical debt in a high-velocity engineering organization?',
    options: [
      'Having unit test coverage above 90%.',
      'High change failure rate, extended lead time for changes, and high cognitive load across cross-functional teams.',
      'Using TypeScript instead of raw JavaScript.',
      'Using Docker containers.'
    ],
    correctIndex: 1,
    rationale: 'DORA metrics and cognitive load directly reflect architectural friction and unmanaged technical debt.'
  }
];

export const SkillDiagnosticModal: React.FC<SkillDiagnosticModalProps> = ({
  skill,
  isOpen,
  onClose,
  onLevelUp,
}) => {
  if (!isOpen || !skill) return null;

  const questions = SKILL_QUESTIONS_MAP[skill.id] || GENERIC_QUESTIONS;
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showRationale, setShowRationale] = useState(false);
  const [isFinished, setIsFinished] = useState(false);

  const activeQ = questions[currentIdx];
  const currentSelection = selectedAnswers[currentIdx];

  const handleSelectOption = (index: number) => {
    if (showRationale) return;
    const updated = [...selectedAnswers];
    updated[currentIdx] = index;
    setSelectedAnswers(updated);
    setShowRationale(true);
  };

  const handleNext = () => {
    setShowRationale(false);
    if (currentIdx < questions.length - 1) {
      setCurrentIdx(currentIdx + 1);
    } else {
      setIsFinished(true);
      // Calculate score
      const correctCount = selectedAnswers.filter(
        (ans, i) => ans === questions[i].correctIndex
      ).length;

      if (correctCount >= 2) {
        // Trigger celebratory confetti
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      }
    }
  };

  const correctCount = selectedAnswers.filter(
    (ans, i) => ans === questions[i].correctIndex
  ).length;

  const passed = correctCount >= 2;
  const newLevel = passed ? Math.min(5, skill.level + 1) : skill.level;
  const xpReward = passed ? 300 : 75;

  const handleClaimLevelUp = () => {
    if (passed) {
      onLevelUp(skill.id, newLevel, xpReward);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-xl rounded-2xl border border-slate-800 bg-slate-900 p-6 md:p-8 shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white"
        >
          <X className="h-5 w-5" />
        </button>

        {!isFinished ? (
          <div>
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="rounded-md bg-indigo-500/10 px-2 py-0.5 text-xs font-semibold text-indigo-400 border border-indigo-500/20">
                  Skill Diagnostic
                </span>
                <span className="text-xs text-slate-400">
                  Question {currentIdx + 1} of {questions.length}
                </span>
              </div>
              <div className="text-xs font-bold text-slate-300">
                {skill.name} (Level {skill.level} → {Math.min(5, skill.level + 1)})
              </div>
            </div>

            {/* Question Card */}
            <div className="mt-5 space-y-4">
              <h3 className="text-base font-bold text-white leading-relaxed">
                {activeQ.question}
              </h3>

              {/* Options */}
              <div className="space-y-2.5 pt-2">
                {activeQ.options.map((opt, i) => {
                  const isSelected = currentSelection === i;
                  const isCorrect = activeQ.correctIndex === i;

                  let optionStyle = 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700 hover:bg-slate-800/60';
                  if (showRationale) {
                    if (isCorrect) {
                      optionStyle = 'border-emerald-500/80 bg-emerald-950/40 text-emerald-200';
                    } else if (isSelected && !isCorrect) {
                      optionStyle = 'border-rose-500/80 bg-rose-950/40 text-rose-200';
                    } else {
                      optionStyle = 'border-slate-800 bg-slate-950/30 text-slate-500 opacity-60';
                    }
                  }

                  return (
                    <button
                      key={i}
                      onClick={() => handleSelectOption(i)}
                      disabled={showRationale}
                      className={`w-full rounded-xl border p-3.5 text-left text-xs font-medium transition-all flex items-start gap-3 ${optionStyle}`}
                    >
                      <span className="flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full border border-slate-700 text-[10px] font-bold">
                        {String.fromCharCode(65 + i)}
                      </span>
                      <span className="flex-1 leading-relaxed">{opt}</span>
                      {showRationale && isCorrect && (
                        <CheckCircle2 className="h-4 w-4 text-emerald-400 flex-shrink-0" />
                      )}
                      {showRationale && isSelected && !isCorrect && (
                        <AlertCircle className="h-4 w-4 text-rose-400 flex-shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Rationale explanation card */}
              {showRationale && (
                <div className="rounded-xl border border-indigo-500/20 bg-indigo-950/30 p-3.5 text-xs text-indigo-200 leading-relaxed animate-in fade-in">
                  <span className="font-bold text-indigo-300 mr-1.5">Architectural Rationale:</span>
                  {activeQ.rationale}
                </div>
              )}
            </div>

            {/* Next Button */}
            <div className="mt-6 flex justify-end">
              <button
                onClick={handleNext}
                disabled={!showRationale}
                className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-semibold text-white shadow-md shadow-indigo-600/30 hover:bg-indigo-500 transition-all disabled:opacity-40"
              >
                <span>{currentIdx < questions.length - 1 ? 'Next Question' : 'Complete Diagnostic'}</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        ) : (
          /* Finished State */
          <div className="py-4 text-center">
            <div className={`mx-auto flex h-14 w-14 items-center justify-center rounded-2xl shadow-lg ${
              passed
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-emerald-500/20'
                : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
            }`}>
              {passed ? <Award className="h-8 w-8" /> : <RefreshCw className="h-8 w-8" />}
            </div>

            <h3 className="mt-4 text-xl font-bold text-white">
              {passed ? 'Diagnostic Passed! Skill Level Up' : 'Diagnostic Completed'}
            </h3>
            <p className="mt-1 text-xs text-slate-400">
              You scored <span className="font-bold text-white">{correctCount} of {questions.length}</span> correct
            </p>

            {passed ? (
              <div className="mt-5 rounded-xl border border-emerald-500/30 bg-emerald-950/20 p-4 text-left">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-400">Skill Proficiency Calibrated</p>
                    <p className="text-sm font-bold text-white">{skill.name}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="rounded-lg bg-slate-800 px-2 py-1 text-xs font-semibold text-slate-300">
                      Lvl {skill.level}
                    </span>
                    <ArrowRight className="h-4 w-4 text-emerald-400" />
                    <span className="rounded-lg bg-emerald-500/20 px-2 py-1 text-xs font-bold text-emerald-300 border border-emerald-500/40">
                      Lvl {newLevel}
                    </span>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-emerald-500/20 pt-2 text-xs">
                  <span className="text-slate-400">Proficiency XP Earned:</span>
                  <span className="font-bold text-amber-400 flex items-center gap-1">
                    <Zap className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                    +{xpReward} XP
                  </span>
                </div>
              </div>
            ) : (
              <div className="mt-5 rounded-xl border border-amber-500/30 bg-amber-950/20 p-4 text-xs text-amber-300">
                You earned +{xpReward} XP for completing this diagnostic. Review the related learning path modules to reinforce these competencies and retry anytime!
              </div>
            )}

            <div className="mt-6 flex justify-center">
              <button
                onClick={handleClaimLevelUp}
                className="rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-6 py-2.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:from-indigo-500 hover:to-violet-500 transition-all"
              >
                {passed ? 'Update My Skills Graph' : 'Back to Skills Graph'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
