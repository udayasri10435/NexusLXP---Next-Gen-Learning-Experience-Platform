import React, { useState, useMemo } from 'react';
import { SkillNode, SkillCategory } from '../../types/lxp';
import {
  Layers,
  Sparkles,
  Zap,
  Target,
  Search,
  Filter,
  Users2,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Brain,
  Info
} from 'lucide-react';

interface SkillsGraphProps {
  skills: SkillNode[];
  onSelectSkillForDiagnostic: (skill: SkillNode) => void;
  targetRole: string;
}

const CATEGORY_META: Record<
  SkillCategory,
  { name: string; color: string; bg: string; border: string; glow: string }
> = {
  ai_ml: {
    name: 'AI & Machine Learning',
    color: '#818cf8', // indigo-400
    bg: 'rgba(99, 102, 241, 0.15)',
    border: '#6366f1',
    glow: 'rgba(99, 102, 241, 0.4)',
  },
  systems_cloud: {
    name: 'Systems & Cloud',
    color: '#38bdf8', // sky-400
    bg: 'rgba(56, 189, 248, 0.15)',
    border: '#0284c7',
    glow: 'rgba(56, 189, 248, 0.4)',
  },
  product_leadership: {
    name: 'Product & Leadership',
    color: '#34d399', // emerald-400
    bg: 'rgba(52, 211, 153, 0.15)',
    border: '#059669',
    glow: 'rgba(52, 211, 153, 0.4)',
  },
  security_data: {
    name: 'Security & Governance',
    color: '#fb7185', // rose-400
    bg: 'rgba(251, 113, 133, 0.15)',
    border: '#e11d48',
    glow: 'rgba(251, 113, 133, 0.4)',
  },
  frontend_dev: {
    name: 'Frontend & UX',
    color: '#f472b6',
    bg: 'rgba(244, 114, 182, 0.15)',
    border: '#db2777',
    glow: 'rgba(244, 114, 182, 0.4)',
  }
};

const LEVEL_LABELS: Record<number, string> = {
  1: 'Novice',
  2: 'Competent',
  3: 'Proficient',
  4: 'Advanced',
  5: 'Master'
};

export const SkillsGraph: React.FC<SkillsGraphProps> = ({
  skills,
  onSelectSkillForDiagnostic,
  targetRole,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<SkillCategory | 'all'>('all');
  const [onlyGaps, setOnlyGaps] = useState<boolean>(false);
  const [searchFilter, setSearchFilter] = useState<string>('');
  const [selectedSkillId, setSelectedSkillId] = useState<string>(skills[0]?.id || '');

  // Filter skills
  const filteredSkills = useMemo(() => {
    return skills.filter((s) => {
      if (selectedCategory !== 'all' && s.category !== selectedCategory) return false;
      if (onlyGaps && s.level >= s.targetLevel) return false;
      if (searchFilter.trim() && !s.name.toLowerCase().includes(searchFilter.toLowerCase())) return false;
      return true;
    });
  }, [skills, selectedCategory, onlyGaps, searchFilter]);

  const selectedSkill = skills.find((s) => s.id === selectedSkillId) || skills[0];

  // Calculate high-level stats
  const totalSkills = skills.length;
  const masteredCount = skills.filter((s) => s.level >= 4).length;
  const gapsToCloseCount = skills.filter((s) => s.level < s.targetLevel).length;
  const avgLevel = (skills.reduce((acc, s) => acc + s.level, 0) / (totalSkills || 1)).toFixed(1);

  // SVG dimensions
  const svgWidth = 720;
  const svgHeight = 490;

  // Build connection links
  const connectionLinks = useMemo(() => {
    const links: { source: SkillNode; target: SkillNode; key: string }[] = [];
    const skillMap = new Map(skills.map((s) => [s.id, s]));

    skills.forEach((source) => {
      source.connections.forEach((targetId) => {
        const target = skillMap.get(targetId);
        if (target && source.x && source.y && target.x && target.y) {
          // Avoid duplicate bidirectional lines
          const key = [source.id, target.id].sort().join('--');
          if (!links.some((l) => l.key === key)) {
            links.push({ source, target, key });
          }
        }
      });
    });
    return links;
  }, [skills]);

  return (
    <div className="space-y-6">
      {/* Header Bar with KPI Metrics */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded-md bg-indigo-500/10 px-2.5 py-1 text-xs font-semibold text-indigo-400 border border-indigo-500/20">
                Skills Ontology & Career Graph
              </span>
              <span className="text-xs text-slate-400">Target Role: <strong className="text-white">{targetRole}</strong></span>
            </div>
            <h1 className="mt-2 text-2xl font-bold tracking-tight text-white">
              Dynamic Competency & Knowledge Graph
            </h1>
            <p className="mt-1 text-xs text-slate-400 max-w-2xl">
              Real-time skills graph tracking verified competencies, prerequisite linkages, and targeted proficiency gaps required for promotion.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onSelectSkillForDiagnostic(selectedSkill)}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:from-indigo-500 hover:to-violet-500 transition-all"
            >
              <Zap className="h-4 w-4 fill-amber-300 text-amber-300" />
              <span>Diagnose & Level Up</span>
            </button>
          </div>
        </div>

        {/* Metric Cards Row */}
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3 border-t border-slate-800/80 pt-4">
          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
            <div className="text-[11px] font-medium text-slate-400">Tracked Competencies</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-xl font-bold text-white">{totalSkills}</span>
              <span className="text-[10px] text-indigo-400">Nodes</span>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
            <div className="text-[11px] font-medium text-slate-400">Mastered (L4 - L5)</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-xl font-bold text-emerald-400">{masteredCount}</span>
              <span className="text-[10px] text-slate-500">of {totalSkills}</span>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
            <div className="text-[11px] font-medium text-slate-400">Target Role Gaps</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-xl font-bold text-amber-400">{gapsToCloseCount}</span>
              <span className="text-[10px] text-amber-500/80">Pending Upgrades</span>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
            <div className="text-[11px] font-medium text-slate-400">Average Proficiency</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-xl font-bold text-cyan-400">{avgLevel}</span>
              <span className="text-[10px] text-slate-500">/ 5.0 (Proficient)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Graph Filters & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-800 bg-slate-900/40 p-3">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition-all ${
              selectedCategory === 'all'
                ? 'bg-slate-700 text-white'
                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            All Clusters ({skills.length})
          </button>

          {(Object.keys(CATEGORY_META) as SkillCategory[]).map((cat) => {
            const count = skills.filter((s) => s.category === cat).length;
            if (count === 0) return null;
            const meta = CATEGORY_META[cat];
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'border text-white shadow-sm'
                    : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
                style={{
                  backgroundColor: isSelected ? meta.bg : undefined,
                  borderColor: isSelected ? meta.border : 'transparent',
                }}
              >
                <span
                  className="h-2 w-2 rounded-full"
                  style={{ backgroundColor: meta.color }}
                />
                <span>{meta.name}</span>
                <span className="text-[10px] text-slate-500">({count})</span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-3">
          {/* Target Gaps Only Toggle */}
          <button
            onClick={() => setOnlyGaps(!onlyGaps)}
            className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-semibold transition-all ${
              onlyGaps
                ? 'border-amber-500/50 bg-amber-500/10 text-amber-300'
                : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
            <span>Target Gaps Only</span>
          </button>

          {/* Quick search input */}
          <div className="relative">
            <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-500" />
            <input
              type="text"
              placeholder="Filter node..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="rounded-lg border border-slate-800 bg-slate-950 py-1 pl-8 pr-3 text-xs text-slate-200 placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Main Interactive Visualizer Grid (Graph Canvas + Selected Node Card) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Interactive SVG Ontology Map (8 cols) */}
        <div className="lg:col-span-8 rounded-2xl border border-slate-800 bg-slate-950 p-4 relative overflow-hidden flex flex-col justify-center items-center shadow-inner">
          {/* Grid background styling */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(circle, #4f46e5 1px, transparent 1px)',
              backgroundSize: '24px 24px'
            }}
          />

          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full h-auto max-h-[520px] select-none"
          >
            {/* Connection Lines */}
            <g className="links">
              {connectionLinks.map((link) => {
                const isHighlighted =
                  selectedSkill &&
                  (link.source.id === selectedSkill.id || link.target.id === selectedSkill.id);

                return (
                  <line
                    key={link.key}
                    x1={link.source.x}
                    y1={link.source.y}
                    x2={link.target.x}
                    y2={link.target.y}
                    stroke={isHighlighted ? '#818cf8' : '#334155'}
                    strokeWidth={isHighlighted ? 2.5 : 1.2}
                    strokeDasharray={isHighlighted ? 'none' : '4 3'}
                    strokeOpacity={isHighlighted ? 0.9 : 0.4}
                  />
                );
              })}
            </g>

            {/* Skill Nodes */}
            <g className="nodes">
              {filteredSkills.map((skill) => {
                const isSelected = selectedSkill?.id === skill.id;
                const isGap = skill.level < skill.targetLevel;
                const meta = CATEGORY_META[skill.category];
                const x = skill.x || 300;
                const y = skill.y || 200;

                return (
                  <g
                    key={skill.id}
                    transform={`translate(${x}, ${y})`}
                    onClick={() => setSelectedSkillId(skill.id)}
                    className="cursor-pointer transition-transform duration-200 hover:scale-110"
                  >
                    {/* Pulsing halo if target gap */}
                    {isGap && (
                      <circle
                        r="24"
                        fill="none"
                        stroke="#f59e0b"
                        strokeWidth="1.5"
                        strokeDasharray="3 2"
                        className="animate-spin"
                        style={{ transformOrigin: '0 0', animationDuration: '8s' }}
                        opacity={0.6}
                      />
                    )}

                    {/* Outer selection ring */}
                    {isSelected && (
                      <circle
                        r="26"
                        fill="none"
                        stroke="#818cf8"
                        strokeWidth="2.5"
                        opacity={0.8}
                      />
                    )}

                    {/* Background bubble */}
                    <circle
                      r="18"
                      fill={meta.bg}
                      stroke={meta.border}
                      strokeWidth={isSelected ? 2.5 : 1.5}
                    />

                    {/* Level Number */}
                    <text
                      textAnchor="middle"
                      dy="4"
                      fontSize="11"
                      fontWeight="bold"
                      fill="#ffffff"
                    >
                      {skill.level}
                    </text>

                    {/* Label below node */}
                    <text
                      textAnchor="middle"
                      dy="32"
                      fontSize="10"
                      fontWeight={isSelected ? 'bold' : '500'}
                      fill={isSelected ? '#ffffff' : '#94a3b8'}
                      className="transition-colors pointer-events-none"
                    >
                      {skill.name.length > 20 ? skill.name.slice(0, 18) + '...' : skill.name}
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>

          {/* Interactive Legend */}
          <div className="mt-2 flex flex-wrap items-center justify-between w-full border-t border-slate-900 pt-2 px-2 text-[11px] text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full border border-amber-400 bg-amber-400/20" />
              <span>Amber Ring = Target Role Gap</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full border border-indigo-400 bg-indigo-400" />
              <span>Blue Ring = Selected Skill</span>
            </span>
            <span>Click any node to inspect details</span>
          </div>
        </div>

        {/* Selected Skill Detail Panel (4 cols) */}
        <div className="lg:col-span-4 rounded-2xl border border-slate-800 bg-slate-900/70 p-6 flex flex-col justify-between backdrop-blur-md">
          {selectedSkill ? (
            <div className="space-y-5">
              <div>
                <div className="flex items-center justify-between">
                  <span
                    className="rounded-md px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wider"
                    style={{
                      color: CATEGORY_META[selectedSkill.category].color,
                      backgroundColor: CATEGORY_META[selectedSkill.category].bg,
                    }}
                  >
                    {CATEGORY_META[selectedSkill.category].name}
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <Users2 className="h-3.5 w-3.5 text-slate-500" />
                    {selectedSkill.endorsements} Endorsements
                  </span>
                </div>

                <h3 className="mt-2 text-lg font-bold text-white">
                  {selectedSkill.name}
                </h3>
                <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                  {selectedSkill.description}
                </p>
              </div>

              {/* Proficiency Level Gauge */}
              <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-4 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">Current Proficiency</span>
                  <span className="font-bold text-white">
                    Level {selectedSkill.level}: {LEVEL_LABELS[selectedSkill.level]}
                  </span>
                </div>

                {/* Level segments 1 to 5 */}
                <div className="grid grid-cols-5 gap-1.5">
                  {[1, 2, 3, 4, 5].map((lvl) => {
                    const isFilled = lvl <= selectedSkill.level;
                    const isTarget = lvl === selectedSkill.targetLevel;

                    return (
                      <div key={lvl} className="space-y-1">
                        <div
                          className={`h-2 rounded-full transition-all ${
                            isFilled
                              ? 'bg-gradient-to-r from-indigo-500 to-cyan-400 shadow-sm'
                              : isTarget
                              ? 'border border-amber-400/60 bg-amber-400/20'
                              : 'bg-slate-800'
                          }`}
                        />
                        <div className="text-[10px] text-center text-slate-500">
                          {isTarget ? (
                            <span className="font-bold text-amber-400">Target</span>
                          ) : (
                            lvl
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Gap Warning or Mastery Badge */}
                {selectedSkill.level < selectedSkill.targetLevel ? (
                  <div className="flex items-center gap-2 rounded-lg bg-amber-500/10 p-2 text-[11px] text-amber-300 border border-amber-500/20">
                    <AlertTriangle className="h-4 w-4 text-amber-400 flex-shrink-0" />
                    <span>
                      Gap of +{selectedSkill.targetLevel - selectedSkill.level} levels needed for {targetRole}.
                    </span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 rounded-lg bg-emerald-500/10 p-2 text-[11px] text-emerald-300 border border-emerald-500/20">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 flex-shrink-0" />
                    <span>Proficiency meets target role requirements!</span>
                  </div>
                )}
              </div>

              {/* Connected Prerequisite & Successor Skills */}
              <div>
                <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Interconnected Skills
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedSkill.connections.map((connId) => {
                    const conn = skills.find((s) => s.id === connId);
                    if (!conn) return null;
                    return (
                      <button
                        key={connId}
                        onClick={() => setSelectedSkillId(connId)}
                        className="rounded-lg border border-slate-800 bg-slate-950/70 px-2.5 py-1 text-xs text-slate-300 hover:border-indigo-500 hover:text-white transition-colors"
                      >
                        {conn.name} (L{conn.level})
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Recent Activity */}
              {selectedSkill.recentActivity && (
                <div className="rounded-lg border border-slate-800/80 bg-slate-950/50 p-3 text-[11px] text-slate-400">
                  <span className="font-semibold text-slate-300 block mb-0.5">Recent Evidence:</span>
                  <span>{selectedSkill.recentActivity}</span>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center text-slate-500 py-10">Select a skill node</div>
          )}

          {/* Action Trigger */}
          <div className="pt-4 border-t border-slate-800">
            <button
              onClick={() => onSelectSkillForDiagnostic(selectedSkill)}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:bg-indigo-500 transition-all"
            >
              <Zap className="h-4 w-4 fill-amber-300 text-amber-300" />
              <span>Take Diagnostic to Level Up</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
