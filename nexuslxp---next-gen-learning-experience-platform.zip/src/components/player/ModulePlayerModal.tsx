import React, { useState, useRef } from 'react';
import { LearningModule, Milestone } from '../../types/lxp';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Code2,
  BookOpen,
  Sparkles,
  MessageSquare,
  CheckCircle2,
  Award,
  Zap,
  Clock,
  ExternalLink,
  ChevronRight,
  Terminal,
  Send,
  HelpCircle,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface ModulePlayerModalProps {
  module: LearningModule | null;
  milestone: Milestone | null;
  isOpen: boolean;
  onClose: () => void;
  onCompleteModule: (moduleId: string, earnedXp: number) => void;
}

export const ModulePlayerModal: React.FC<ModulePlayerModalProps> = ({
  module,
  milestone,
  isOpen,
  onClose,
  onCompleteModule,
}) => {
  if (!isOpen || !module || !milestone) return null;

  // Active view tab inside player
  const [activeTab, setActiveTab] = useState<'content' | 'sandbox' | 'quiz' | 'notes'>('content');

  // Video player simulation state
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<'1x' | '1.25x' | '1.5x'>('1.25x');
  const [progressSec, setProgressSec] = useState(140);
  const totalDurationSec = module.durationMinutes * 60;

  // Interactive sandbox state
  const [codeValue, setCodeValue] = useState(
    module.interactiveChallenge?.starterCode || `// Lab implementation\nfunction solveProblem() {\n  return true;\n}`
  );
  const [testResults, setTestResults] = useState<{ passed: boolean; message: string }[] | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  // Quiz state
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [submittedQuiz, setSubmittedQuiz] = useState(false);

  // AI Mentor Companion state
  const [chatMessages, setChatMessages] = useState<
    { sender: 'user' | 'assistant'; text: string; time: string }[]
  >([
    {
      sender: 'assistant',
      text: `Hello Alex! I am your Socratic AI Copilot for "${module.title}". As you study this module, feel free to ask me for architectural counter-arguments, real-world case studies, or conceptual analogies.`,
      time: 'Just now'
    }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isAiThinking, setIsAiThinking] = useState(false);

  // Personal notes
  const [learnerNotes, setLearnerNotes] = useState(
    '• Key takeaway: BM25 sparse index captures exact error codes, while dense embeddings capture conceptual semantic similarity.\n• Action: Evaluate reciprocal rank fusion (RRF) for next week\'s sprint.'
  );

  // Run automated test cases in interactive sandbox
  const handleRunTests = () => {
    setIsTesting(true);
    setTimeout(() => {
      setIsTesting(false);
      setTestResults([
        { passed: true, message: 'Test 1: Reciprocal Rank distribution strictly monotonic [PASS]' },
        { passed: true, message: 'Test 2: Latency under 15ms threshold under concurrency [PASS]' },
        { passed: true, message: 'Test 3: Handles edge-case empty token embeddings gracefully [PASS]' }
      ]);
    }, 600);
  };

  // Handle quiz option selection
  const handleQuizSelect = (qId: string, optIndex: number) => {
    if (submittedQuiz) return;
    setSelectedAnswers((prev) => ({ ...prev, [qId]: optIndex }));
  };

  // Submit quiz
  const handleQuizSubmit = () => {
    setSubmittedQuiz(true);
  };

  // Socratic Copilot prompt submissions
  const handleSendChat = (promptText?: string) => {
    const textToSend = promptText || chatInput;
    if (!textToSend.trim()) return;

    const userMsg = {
      sender: 'user' as const,
      text: textToSend,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages((prev) => [...prev, userMsg]);
    if (!promptText) setChatInput('');
    setIsAiThinking(true);

    setTimeout(() => {
      let reply = '';
      const lower = textToSend.toLowerCase();

      if (lower.includes('staff') || lower.includes('senior') || lower.includes('explain')) {
        reply = `From a Staff Engineer vantage point: The crucial trade-off isn't raw recall; it's the P99 latency SLA and index memory footprint. When using dense vectors, each billion tokens costs ~4GB in RAM for uncompressed float32. By layering BM25 + IVF-PQ, you achieve 94% of the recall with 1/8th the memory overhead.`;
      } else if (lower.includes('failure') || lower.includes('risk')) {
        reply = `The top production failure mode is "Semantic Drift with Sparse Edge Cases": When users query exact alphanumeric strings (e.g. invoice IDs or error codes like 'ERR_SOCKET_409'), pure vector embeddings fail because they generalize away unique character identifiers. Always enforce dual lexical indexing!`;
      } else {
        reply = `Consider this Socratic checkpoint: If an upstream provider rate-limits your embedding generation endpoint during a spike of 10,000 requests/sec, how should your retrieval tier gracefully degrade without returning 500 server errors? (Hint: consider cached local keyword indices).`;
      }

      setChatMessages((prev) => [
        ...prev,
        {
          sender: 'assistant',
          text: reply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      setIsAiThinking(false);
    }, 800);
  };

  // Complete module
  const handleComplete = () => {
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.6 }
    });
    onCompleteModule(module.id, module.xpReward);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 p-2 sm:p-4 backdrop-blur-md">
      <div className="relative flex h-[94vh] w-full max-w-6xl flex-col rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden">
        {/* Top Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950/80 px-6 py-3.5">
          <div className="flex items-center gap-3 min-w-0">
            <span className="rounded-md bg-indigo-500/10 px-2.5 py-1 text-xs font-semibold text-indigo-400 border border-indigo-500/20 truncate">
              {milestone.title}
            </span>
            <span className="text-slate-600 hidden sm:inline">•</span>
            <h2 className="text-sm font-bold text-white truncate">{module.title}</h2>
          </div>

          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-xs font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-md border border-amber-500/20">
              <Zap className="h-3.5 w-3.5 fill-amber-400" />
              +{module.xpReward} XP
            </span>

            <button
              onClick={onClose}
              className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Content Body Grid: Main Content (7 cols) + AI & Notes Sidebar (5 cols) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 overflow-hidden">
          {/* Main Interactive Stage (7 cols) */}
          <div className="lg:col-span-7 flex flex-col border-b lg:border-b-0 lg:border-r border-slate-800 overflow-y-auto">
            {/* View Switcher Bar */}
            <div className="flex items-center justify-between border-b border-slate-800/80 bg-slate-950/50 px-6 py-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('content')}
                  className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                    activeTab === 'content'
                      ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <BookOpen className="h-3.5 w-3.5" />
                  <span>Interactive Lecture</span>
                </button>

                {module.interactiveChallenge && (
                  <button
                    onClick={() => setActiveTab('sandbox')}
                    className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                      activeTab === 'sandbox'
                        ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <Code2 className="h-3.5 w-3.5 text-amber-400" />
                    <span>Scenario Sandbox</span>
                  </button>
                )}

                {module.quiz && module.quiz.length > 0 && (
                  <button
                    onClick={() => setActiveTab('quiz')}
                    className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                      activeTab === 'quiz'
                        ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <HelpCircle className="h-3.5 w-3.5 text-emerald-400" />
                    <span>Checkpoint Quiz</span>
                  </button>
                )}
              </div>

              <div className="text-[11px] text-slate-400 flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {module.durationMinutes} min module
              </div>
            </div>

            {/* TAB 1: Lecture & Video Player */}
            {activeTab === 'content' && (
              <div className="p-6 space-y-6">
                {/* Media Player Component */}
                <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-slate-950 aspect-video flex flex-col justify-between p-4 shadow-xl">
                  {/* Video Screen simulation */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex items-center justify-center">
                    <div className="text-center p-6">
                      <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-indigo-600/80 text-white shadow-lg shadow-indigo-600/40 hover:scale-105 transition-transform cursor-pointer"
                        onClick={() => setIsPlaying(!isPlaying)}
                      >
                        {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 ml-0.5" />}
                      </div>
                      <p className="mt-3 text-xs font-bold text-white tracking-wide">
                        {isPlaying ? 'Playing Masterclass Lecture' : 'Click to Play Masterclass Stream'}
                      </p>
                      <p className="text-[11px] text-slate-400">Speaker: Dr. David Chen • Staff AI Fellow</p>
                    </div>
                  </div>

                  {/* Player Controls Overlay */}
                  <div className="relative z-10 mt-auto pt-4 space-y-2">
                    {/* Scrubber Bar */}
                    <div className="h-1.5 w-full bg-slate-800 rounded-full cursor-pointer overflow-hidden">
                      <div
                        className="h-full bg-indigo-500 rounded-full"
                        style={{ width: `${(progressSec / totalDurationSec) * 100}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => setIsPlaying(!isPlaying)}
                          className="text-white hover:text-indigo-400"
                        >
                          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </button>
                        <button
                          onClick={() => setProgressSec(0)}
                          className="hover:text-white"
                        >
                          <RotateCcw className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => setIsMuted(!isMuted)}
                          className="hover:text-white"
                        >
                          {isMuted ? <VolumeX className="h-4 w-4 text-rose-400" /> : <Volume2 className="h-4 w-4" />}
                        </button>
                        <span className="text-[11px]">
                          {Math.floor(progressSec / 60)}:{(progressSec % 60).toString().padStart(2, '0')} / {module.durationMinutes}:00
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            if (playbackSpeed === '1x') setPlaybackSpeed('1.25x');
                            else if (playbackSpeed === '1.25x') setPlaybackSpeed('1.5x');
                            else setPlaybackSpeed('1x');
                          }}
                          className="rounded bg-slate-800 px-2 py-0.5 text-[11px] font-bold text-slate-300 hover:text-white"
                        >
                          {playbackSpeed} Speed
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Lecture Deep-Dive Text */}
                <div className="prose prose-invert max-w-none text-xs leading-relaxed space-y-3">
                  <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4">
                    <h3 className="text-sm font-bold text-white mb-2">Module Abstract & Learning Objectives</h3>
                    <p className="text-slate-300">{module.summary}</p>
                  </div>

                  <div className="whitespace-pre-line text-slate-300 font-sans">
                    {module.contentMarkdown}
                  </div>

                  {module.resources && module.resources.length > 0 && (
                    <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-4">
                      <p className="text-xs font-semibold text-slate-200 mb-2">Curated Research & References:</p>
                      <div className="space-y-1.5">
                        {module.resources.map((res, i) => (
                          <a
                            key={i}
                            href={res.url}
                            target="_blank"
                            rel="noreferrer"
                            className="flex items-center gap-2 text-indigo-400 hover:text-indigo-300 underline text-xs"
                          >
                            <ExternalLink className="h-3.5 w-3.5" />
                            <span>{res.title} ({res.type.toUpperCase()})</span>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB 2: Scenario Sandbox (Hands-on Challenge) */}
            {activeTab === 'sandbox' && module.interactiveChallenge && (
              <div className="p-6 space-y-4">
                <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-4">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                    <Terminal className="h-4 w-4" />
                    <span>Challenge Prompt</span>
                  </div>
                  <p className="mt-1 text-xs text-slate-300">
                    {module.interactiveChallenge.instruction}
                  </p>
                </div>

                {/* Code Editor simulation */}
                <div className="rounded-xl border border-slate-800 bg-slate-950 overflow-hidden">
                  <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900/80 px-4 py-2 text-xs text-slate-400">
                    <span className="font-mono text-indigo-400">solution.ts</span>
                    <button
                      onClick={() => setCodeValue(module.interactiveChallenge?.sampleSolution || '')}
                      className="text-[11px] text-indigo-400 hover:text-indigo-300"
                    >
                      Fill Reference Solution
                    </button>
                  </div>
                  <textarea
                    value={codeValue}
                    onChange={(e) => setCodeValue(e.target.value)}
                    rows={12}
                    className="w-full bg-slate-950 p-4 font-mono text-xs text-slate-200 focus:outline-none resize-none leading-relaxed"
                    spellCheck={false}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">
                    Automated sandbox verifies state determinism & latency budgets.
                  </span>
                  <button
                    onClick={handleRunTests}
                    disabled={isTesting}
                    className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-600 to-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:from-amber-500 hover:to-indigo-500"
                  >
                    {isTesting ? (
                      <>
                        <div className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />
                        <span>Running Test Suite...</span>
                      </>
                    ) : (
                      <>
                        <Play className="h-3.5 w-3.5" />
                        <span>Run Automated Tests</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Test results output */}
                {testResults && (
                  <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 space-y-2 font-mono text-xs">
                    <p className="font-bold text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="h-4 w-4" />
                      All Automated Verification Tests Passed!
                    </p>
                    {testResults.map((res, idx) => (
                      <p key={idx} className="text-slate-300 text-[11px]">
                        {res.message}
                      </p>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: Checkpoint Quiz */}
            {activeTab === 'quiz' && module.quiz && (
              <div className="p-6 space-y-6">
                <div className="space-y-4">
                  {module.quiz.map((q, idx) => {
                    const selected = selectedAnswers[q.id];
                    const isCorrect = selected === q.correctIndex;

                    return (
                      <div key={q.id} className="rounded-xl border border-slate-800 bg-slate-950/70 p-4 space-y-3">
                        <p className="text-xs font-bold text-white">
                          Question {idx + 1}: {q.question}
                        </p>

                        <div className="space-y-2">
                          {q.options.map((opt, optIdx) => {
                            const isChosen = selected === optIdx;
                            let style = 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700';
                            if (submittedQuiz) {
                              if (optIdx === q.correctIndex) {
                                style = 'border-emerald-500/80 bg-emerald-950/40 text-emerald-200';
                              } else if (isChosen && !isCorrect) {
                                style = 'border-rose-500/80 bg-rose-950/40 text-rose-200';
                              }
                            } else if (isChosen) {
                              style = 'border-indigo-500 bg-indigo-950/40 text-indigo-200';
                            }

                            return (
                              <button
                                key={optIdx}
                                onClick={() => handleQuizSelect(q.id, optIdx)}
                                className={`w-full rounded-lg border p-3 text-left text-xs font-medium transition-all ${style}`}
                              >
                                {opt}
                              </button>
                            );
                          })}
                        </div>

                        {submittedQuiz && (
                          <div className="rounded-lg bg-indigo-950/30 border border-indigo-500/20 p-3 text-xs text-indigo-200">
                            <strong>Rationale:</strong> {q.explanation}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {!submittedQuiz && (
                  <button
                    onClick={handleQuizSubmit}
                    className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white hover:bg-indigo-500"
                  >
                    Check Answers
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Socratic AI Study Companion & Personal Notes (Right 5 cols) */}
          <div className="lg:col-span-5 flex flex-col bg-slate-950/40 overflow-hidden">
            {/* Sidebar Header */}
            <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950/70 px-4 py-2.5">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-amber-300" />
                <span className="text-xs font-bold text-white">Socratic AI Mentor & Notes</span>
              </div>
              <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                Online & Ready
              </span>
            </div>

            {/* AI Conversation Stream */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {chatMessages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex flex-col ${
                    msg.sender === 'user' ? 'items-end' : 'items-start'
                  }`}
                >
                  <div
                    className={`max-w-[90%] rounded-2xl p-3 text-xs leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-indigo-600 text-white rounded-br-none shadow-md'
                        : 'border border-slate-800 bg-slate-900/90 text-slate-200 rounded-bl-none shadow-sm'
                    }`}
                  >
                    <p>{msg.text}</p>
                    <span className="mt-1 block text-[9px] text-slate-400 text-right">{msg.time}</span>
                  </div>
                </div>
              ))}

              {isAiThinking && (
                <div className="flex items-center gap-2 text-xs text-slate-400 italic">
                  <div className="h-2 w-2 rounded-full bg-indigo-500 animate-ping" />
                  <span>Synthesizing socratic perspective...</span>
                </div>
              )}
            </div>

            {/* Quick Socratic Prompts */}
            <div className="px-4 py-2 border-t border-slate-800/80 bg-slate-900/30 flex flex-wrap gap-1.5">
              <button
                onClick={() => handleSendChat('Explain the core architectural trade-offs like I am a Staff Architect')}
                className="rounded-full bg-slate-800/80 px-2.5 py-1 text-[10px] text-indigo-300 hover:bg-slate-800 border border-slate-700/60"
              >
                Explain for Staff Architect
              </button>
              <button
                onClick={() => handleSendChat('What are the critical production failure modes?')}
                className="rounded-full bg-slate-800/80 px-2.5 py-1 text-[10px] text-amber-300 hover:bg-slate-800 border border-slate-700/60"
              >
                Failure Modes & Risks
              </button>
              <button
                onClick={() => handleSendChat('Give me a challenging Socratic question to test my understanding.')}
                className="rounded-full bg-slate-800/80 px-2.5 py-1 text-[10px] text-emerald-300 hover:bg-slate-800 border border-slate-700/60"
              >
                Challenge Me
              </button>
            </div>

            {/* Chat Input */}
            <div className="p-3 border-t border-slate-800 bg-slate-950/80 flex items-center gap-2">
              <input
                type="text"
                placeholder="Ask your AI Mentor anything about this module..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendChat()}
                className="flex-1 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
              />
              <button
                onClick={() => handleSendChat()}
                className="rounded-xl bg-indigo-600 p-2 text-white hover:bg-indigo-500 transition-colors"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>

            {/* Personal Notes Drawer */}
            <div className="p-3 border-t border-slate-800 bg-slate-900/60">
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                <span className="flex items-center gap-1 font-semibold text-slate-300">
                  <FileText className="h-3 w-3" />
                  My Timestamped Reflection Notes
                </span>
                <span className="text-[10px] text-emerald-400">Auto-saved to Profile</span>
              </div>
              <textarea
                value={learnerNotes}
                onChange={(e) => setLearnerNotes(e.target.value)}
                rows={2}
                className="w-full rounded-lg border border-slate-800 bg-slate-950 p-2 text-[11px] text-slate-300 placeholder-slate-600 focus:outline-none resize-none font-mono"
              />
            </div>
          </div>
        </div>

        {/* Bottom Action Footer */}
        <div className="flex items-center justify-between border-t border-slate-800 bg-slate-950 px-6 py-3">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Award className="h-4 w-4 text-purple-400" />
            <span>Mastering this module updates your skills graph and unlocks next milestone</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
            >
              Save & Exit
            </button>
            <button
              onClick={handleComplete}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-indigo-600 px-5 py-2 text-xs font-bold text-white shadow-lg shadow-emerald-600/20 hover:from-emerald-500 hover:to-indigo-500 transition-all active:scale-95"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>Mark Complete & Claim +{module.xpReward} XP</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
