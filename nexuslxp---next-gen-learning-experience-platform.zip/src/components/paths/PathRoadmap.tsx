import React, { useState } from 'react';
import {
  LearningPath,
  Milestone,
  LearningModule,
  SkillNode
} from '../../types/lxp';
import {
  CheckCircle2,
  Clock,
  Sparkles,
  Play,
  Code,
  FileText,
  Users2,
  Award,
  Lock,
  ChevronRight,
  TrendingUp,
  Target,
  ArrowRight,
  Check,
  BookmarkCheck
} from 'lucide-react';

interface PathRoadmapProps {
  currentPath: LearningPath;
  allPaths: LearningPath[];
  onSelectPath: (path: LearningPath) => void;
  onOpenModule: (module: LearningModule, milestone: Milestone) => void;
  skills: SkillNode[];
  onOpenGenerator: () => void;
  onOpenCredentials: () => void;
}

export const PathRoadmap: React.FC<PathRoadmapProps> = ({
  currentPath,
  allPaths,
  onSelectPath,
  onOpenModule,
  skills,
  onOpenGenerator,
  onOpenCredentials,
}) => {
  const [selectedMilestoneId, setSelectedMilestoneId] = useState<string>(
    currentPath.milestones.find((m) => m.status === 'in_progress')?.id ||
    currentPath.milestones[0]?.id || ''
  );

  // Compute pathway stats
  const totalModules = currentPath.milestones.flatMap((m) => m.modules).length;
  const completedModules = currentPath.milestones.flatMap((m) => m.modules).filter((m) => m.completed).length;
  const progressPct = totalModules > 0 ? Math.round((completedModules / totalModules) * 100) : 0;

  // Active milestone
  const activeMilestone = currentPath.milestones.find((m) => m.id === selectedMilestoneId) || currentPath.milestones[0];

  const getModuleIcon = (type: LearningModule['type']) => {
    switch (type) {
      case 'video':
        return <Play className="h-4 w-4 text-cyan-400" />;
      case 'interactive_lab':
        return <Code className="h-4 w-4 text-amber-400" />;
      case 'case_study':
        return <FileText className="h-4 w-4 text-emerald-400" />;
      case 'peer_review':
        return <Users2 className="h-4 w-4 text-purple-400" />;
      case 'quiz':
        return <BookmarkCheck className="h-4 w-4 text-rose-400" />;
    }
  };

  const getModuleTypeLabel = (type: LearningModule['type']) => {
    switch (type) {
      case 'video': return 'Masterclass Video';
      case 'interactive_lab': return 'Interactive Lab';
      case 'case_study': return 'Architecture Case Study';
      case 'peer_review': return 'Peer Review Project';
      case 'quiz': return 'Skill Assessment';
    }
  };

  return (
    <div className="space-y-8">
      {/* Path Header Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-950 p-6 md:p-8 shadow-2xl">
        {/* Ambient glow */}
        <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-indigo-500/10 blur-3xl" />
        <div className="absolute right-1/3 -bottom-20 h-64 w-64 rounded-full bg-cyan-500/10 blur-3xl" />

        <div className="relative z-10">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="rounded-full bg-indigo-500/20 px-3 py-1 text-xs font-semibold text-indigo-300 border border-indigo-500/30 flex items-center gap-1.5">
                <Target className="h-3.5 w-3.5 text-indigo-400" />
                Target Role: {currentPath.roleTarget}
              </span>
              <span className="rounded-full bg-slate-800/80 px-2.5 py-1 text-xs font-medium text-slate-300">
                {currentPath.difficulty}
              </span>
              {currentPath.isCustomGenerated && (
                <span className="rounded-full bg-amber-500/20 px-2.5 py-1 text-xs font-semibold text-amber-300 border border-amber-500/30 flex items-center gap-1">
                  <Sparkles className="h-3 w-3" /> AI Tailored
                </span>
              )}
            </div>

            {/* Switch / Explore other paths dropdown */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <select
                  value={currentPath.id}
                  onChange={(e) => {
                    const found = allPaths.find((p) => p.id === e.target.value);
                    if (found) {
                      onSelectPath(found);
                      setSelectedMilestoneId(found.milestones[0]?.id || '');
                    }
                  }}
                  className="rounded-lg border border-slate-700 bg-slate-900/90 py-1.5 pl-3 pr-8 text-xs font-medium text-slate-200 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  {allPaths.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title}
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={onOpenGenerator}
                className="flex items-center gap-1.5 rounded-lg border border-indigo-500/30 bg-indigo-500/10 px-3 py-1.5 text-xs font-medium text-indigo-300 hover:bg-indigo-500/20 transition-colors"
              >
                <Sparkles className="h-3.5 w-3.5 text-amber-300" />
                <span>New Adaptive Path</span>
              </button>
            </div>
          </div>

          <h1 className="mt-4 text-2xl md:text-3xl font-extrabold tracking-tight text-white">
            {currentPath.title}
          </h1>
          <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-300">
            {currentPath.description}
          </p>

          {/* Progress & Readiness Bar */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4 rounded-xl border border-slate-800/80 bg-slate-950/70 p-4 backdrop-blur-sm">
            <div>
              <div className="flex items-center justify-between text-xs font-medium text-slate-400 mb-1.5">
                <span>Path Mastery Progress</span>
                <span className="font-bold text-indigo-400">{progressPct}%</span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 transition-all duration-500 rounded-full"
                  style={{ width: `${progressPct}%` }}
                />
              </div>
              <p className="mt-1 text-[11px] text-slate-500">{completedModules} of {totalModules} modules mastered</p>
            </div>

            <div className="flex items-center gap-3 border-slate-800 md:border-l md:pl-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-400">
                <TrendingUp className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400">Target Role Readiness</p>
                <p className="text-sm font-bold text-white">78% Benchmark</p>
              </div>
            </div>

            <div className="flex items-center gap-3 border-slate-800 md:border-l md:pl-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-500/10 text-cyan-400">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400">Total Duration</p>
                <p className="text-sm font-bold text-white">{currentPath.totalDurationHours} Hours</p>
              </div>
            </div>

            <div className="flex items-center gap-3 border-slate-800 md:border-l md:pl-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-purple-500/10 text-purple-400">
                <Award className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400">Verifiable Credential</p>
                <button
                  onClick={onOpenCredentials}
                  className="text-xs font-semibold text-purple-300 hover:text-purple-200 underline decoration-purple-500/40"
                >
                  View Credential Specs
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Roadmap Section: Milestone Graph + Active Milestone Modules */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Milestone Steps Timeline (Left Column: 5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>Roadmap Milestones</span>
              <span className="rounded-full bg-slate-800 px-2 py-0.5 text-xs text-slate-400">
                {currentPath.milestones.length}
              </span>
            </h2>
            <span className="text-xs text-slate-400">Select to view modules</span>
          </div>

          <div className="relative space-y-3 before:absolute before:left-5 before:top-4 before:bottom-4 before:w-0.5 before:bg-slate-800">
            {currentPath.milestones.map((m, index) => {
              const isSelected = selectedMilestoneId === m.id;
              const isCompleted = m.status === 'completed';
              const isInProgress = m.status === 'in_progress';
              const isLocked = m.status === 'locked';

              return (
                <div
                  key={m.id}
                  onClick={() => !isLocked && setSelectedMilestoneId(m.id)}
                  className={`group relative flex items-start gap-4 rounded-xl border p-4 transition-all duration-200 ${
                    isLocked
                      ? 'border-slate-800/60 bg-slate-900/40 opacity-60 cursor-not-allowed'
                      : isSelected
                      ? 'border-indigo-500/60 bg-slate-900/90 shadow-lg shadow-indigo-500/10 ring-1 ring-indigo-500/40 cursor-pointer'
                      : 'border-slate-800 bg-slate-900/50 hover:border-slate-700 hover:bg-slate-900 cursor-pointer'
                  }`}
                >
                  {/* Status Indicator Bubble */}
                  <div className="relative z-10 mt-0.5 flex-shrink-0">
                    {isCompleted ? (
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30">
                        <Check className="h-4 w-4 stroke-[3]" />
                      </div>
                    ) : isInProgress ? (
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-indigo-600 text-white ring-4 ring-indigo-500/20 animate-pulse">
                        <span className="text-xs font-bold">{index + 1}</span>
                      </div>
                    ) : isLocked ? (
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-800 text-slate-500">
                        <Lock className="h-3.5 w-3.5" />
                      </div>
                    ) : (
                      <div className="flex h-7 w-7 items-center justify-center rounded-full border border-slate-700 bg-slate-800 text-slate-300">
                        <span className="text-xs font-medium">{index + 1}</span>
                      </div>
                    )}
                  </div>

                  {/* Milestone Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                        Milestone {index + 1}
                      </span>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        isCompleted
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : isInProgress
                          ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                          : isLocked
                          ? 'bg-slate-800 text-slate-500'
                          : 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                      }`}>
                        {isCompleted ? 'Completed' : isInProgress ? 'In Progress' : isLocked ? 'Locked' : 'Available'}
                      </span>
                    </div>

                    <h3 className={`mt-1 text-sm font-semibold truncate ${
                      isSelected ? 'text-white' : 'text-slate-200'
                    }`}>
                      {m.title}
                    </h3>
                    <p className="mt-1 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {m.description}
                    </p>

                    <div className="mt-3 flex items-center gap-3 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3 text-slate-500" />
                        {m.estimatedHours}h
                      </span>
                      <span>•</span>
                      <span>{m.modules.length} Modules</span>
                    </div>
                  </div>

                  <ChevronRight className={`h-4 w-4 self-center transition-transform ${
                    isSelected ? 'text-indigo-400 translate-x-1' : 'text-slate-600'
                  }`} />
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Milestone Active Content Modules (Right Column: 7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 backdrop-blur-md">
            {activeMilestone ? (
              <div>
                <div className="border-b border-slate-800 pb-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-indigo-400">
                      Active Milestone Modules
                    </span>
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      Estimated {activeMilestone.estimatedHours} Hours
                    </span>
                  </div>
                  <h2 className="mt-2 text-xl font-bold text-white">
                    {activeMilestone.title}
                  </h2>
                  <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                    {activeMilestone.description}
                  </p>

                  {/* Skills Trained in this Milestone */}
                  <div className="mt-3 flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-medium text-slate-400 mr-1">Skills Targeted:</span>
                    {activeMilestone.skillsTrained.map((skillId) => {
                      const skill = skills.find((s) => s.id === skillId);
                      return (
                        <span
                          key={skillId}
                          className="rounded-md bg-slate-800/90 px-2 py-0.5 text-[11px] font-medium text-slate-200 border border-slate-700/60"
                        >
                          {skill?.name || skillId}
                        </span>
                      );
                    })}
                  </div>
                </div>

                {/* Modules List */}
                <div className="mt-6 space-y-3">
                  {activeMilestone.modules.length === 0 ? (
                    <div className="rounded-xl border border-dashed border-slate-800 p-8 text-center text-slate-400">
                      <Lock className="mx-auto h-8 w-8 text-slate-600 mb-2" />
                      <p className="text-sm font-medium">Modules unlock sequentially</p>
                      <p className="text-xs text-slate-500 mt-1">
                        Complete previous milestone prerequisites to open this module laboratory.
                      </p>
                    </div>
                  ) : (
                    activeMilestone.modules.map((mod, i) => (
                      <div
                        key={mod.id}
                        className={`group relative flex items-start justify-between gap-4 rounded-xl border p-4 transition-all duration-200 ${
                          mod.completed
                            ? 'border-emerald-500/30 bg-emerald-950/10 hover:border-emerald-500/50'
                            : 'border-slate-800 bg-slate-900/80 hover:border-slate-700 hover:bg-slate-900'
                        }`}
                      >
                        <div className="flex items-start gap-3.5 min-w-0">
                          <div className={`mt-0.5 flex h-9 w-9 items-center justify-center rounded-lg border ${
                            mod.completed
                              ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-400'
                              : 'border-slate-700 bg-slate-800/80 text-slate-300'
                          }`}>
                            {mod.completed ? (
                              <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                            ) : (
                              getModuleIcon(mod.type)
                            )}
                          </div>

                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-[11px] font-medium text-slate-400">
                                {getModuleTypeLabel(mod.type)}
                              </span>
                              <span className="text-slate-600">•</span>
                              <span className="text-[11px] text-slate-400 flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {mod.durationMinutes} min
                              </span>
                              <span className="text-slate-600">•</span>
                              <span className="text-[11px] font-semibold text-amber-400">
                                +{mod.xpReward} XP
                              </span>
                            </div>

                            <h4 className="mt-1 text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                              {mod.title}
                            </h4>

                            <p className="mt-1 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                              {mod.summary}
                            </p>
                          </div>
                        </div>

                        {/* Action Launch Button */}
                        <button
                          onClick={() => onOpenModule(mod, activeMilestone)}
                          className={`flex-shrink-0 flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold transition-all shadow-sm ${
                            mod.completed
                              ? 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                              : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-indigo-600/30'
                          }`}
                        >
                          {mod.completed ? (
                            <>
                              <span>Review</span>
                              <ArrowRight className="h-3.5 w-3.5" />
                            </>
                          ) : (
                            <>
                              <span>Start Module</span>
                              <ArrowRight className="h-3.5 w-3.5" />
                            </>
                          )}
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};
