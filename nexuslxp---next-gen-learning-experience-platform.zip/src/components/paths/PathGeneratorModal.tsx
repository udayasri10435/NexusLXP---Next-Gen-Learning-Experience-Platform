import React, { useState } from 'react';
import { Sparkles, X, Compass, Check, ArrowRight, Brain, Clock, Zap } from 'lucide-react';
import { LearningPath, SkillCategory } from '../../types/lxp';

interface PathGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPathCreated: (newPath: LearningPath) => void;
}

const PRESET_ROLES = [
  'Staff AI Systems Architect',
  'Autonomous Multi-Agent Engineer',
  'High-Throughput Distributed Systems Lead',
  'AI Security & Governance Director',
  'Platform Engineering & DevOps Lead'
];

export const PathGeneratorModal: React.FC<PathGeneratorModalProps> = ({
  isOpen,
  onClose,
  onPathCreated,
}) => {
  const [targetRole, setTargetRole] = useState(PRESET_ROLES[0]);
  const [currentLevel, setCurrentLevel] = useState<'Senior' | 'Mid' | 'Lead'>('Senior');
  const [weeklyHours, setWeeklyHours] = useState(6);
  const [selectedFocus, setSelectedFocus] = useState<string[]>([
    'Multi-Agent State Graphs',
    'Hybrid RAG & Vector Indexes',
    'LLM Evals & Observability'
  ]);
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isOpen) return null;

  const focusOptions = [
    'Multi-Agent State Graphs',
    'Hybrid RAG & Vector Indexes',
    'LLM Evals & Observability',
    'Prompt Injection & Red Teaming',
    'Distributed Raft Consensus',
    'Kafka Event Deduplication',
    'Architecture RFC Governance',
    'Team Topologies & Tech Debt'
  ];

  const toggleFocus = (item: string) => {
    if (selectedFocus.includes(item)) {
      setSelectedFocus(selectedFocus.filter((f) => f !== item));
    } else {
      setSelectedFocus([...selectedFocus, item]);
    }
  };

  const handleGenerate = () => {
    setIsGenerating(true);

    // Simulate smart pathway generation
    setTimeout(() => {
      const pathId = `custom_path_${Date.now()}`;
      const generatedPath: LearningPath = {
        id: pathId,
        title: `Adaptive Pathway: ${targetRole}`,
        roleTarget: targetRole,
        description: `Personalized, capability-driven learning sequence tailored for ${currentLevel} engineers advancing to ${targetRole}, prioritized around: ${selectedFocus.join(', ')}.`,
        category: 'ai_ml' as SkillCategory,
        difficulty: 'Advanced',
        totalDurationHours: Math.round(weeklyHours * 5),
        enrolledLearnersCount: 1,
        rating: 5.0,
        skillsCovered: ['llm_agents', 'rag_architectures', 'eval_observability', 'distributed_systems'],
        isCustomGenerated: true,
        milestones: [
          {
            id: `m_gen_1_${Date.now()}`,
            title: `Phase 1: Accelerated Diagnostics & Foundational Synthesis`,
            description: `Calibrate existing competence in ${selectedFocus[0] || 'core concepts'} and eliminate knowledge gaps with focused scenario simulations.`,
            estimatedHours: Math.round(weeklyHours * 1.5),
            skillsTrained: ['llm_agents', 'rag_architectures'],
            status: 'in_progress',
            modules: [
              {
                id: `mod_gen_101_${Date.now()}`,
                title: `Diagnostic Masterclass: Modern ${selectedFocus[0] || 'Systems'} Paradigms`,
                type: 'video',
                durationMinutes: 28,
                xpReward: 200,
                completed: false,
                summary: `Comprehensive analysis of state-of-the-art trade-offs and battle-tested patterns for high-reliability systems.`,
                contentMarkdown: `### Personalized Architecture Synthesis for ${targetRole}
Based on your current baseline as a ${currentLevel} engineer, this module focuses on real-world constraints:
1. Low latency retrieval under 15ms
2. Dynamic memory checkpointing
3. Token budget telemetry and circuit breakers.`
              },
              {
                id: `mod_gen_102_${Date.now()}`,
                title: `Interactive Challenge: Fault-Tolerant Implementation`,
                type: 'interactive_lab',
                durationMinutes: 45,
                xpReward: 350,
                completed: false,
                summary: `Build and stress-test an implementation against chaotic simulated failure conditions.`,
                contentMarkdown: `### Interactive Lab: Resilient State Transition
Write the handler logic to ensure state recovery when node failures occur mid-transaction.`,
                interactiveChallenge: {
                  instruction: 'Implement state reconciliation to recover interrupted sessions.',
                  starterCode: `// State Recovery Engine
interface Session {
  id: string;
  status: 'pending' | 'processing' | 'committed';
  timestamp: number;
}

function reconcileSession(session: Session, currentTime: number): 'retry' | 'abort' | 'commit' {
  // If stuck in processing for > 3000ms, retry
  const timeoutMs = 3000;
  if (session.status === 'processing' && (currentTime - session.timestamp > timeoutMs)) {
    return 'retry';
  }
  return session.status === 'committed' ? 'commit' : 'retry';
}`,
                  sampleSolution: `function reconcileSession(session: Session, currentTime: number): 'retry' | 'abort' | 'commit' {
  if (session.status === 'processing' && (currentTime - session.timestamp > 3000)) return 'retry';
  return session.status === 'committed' ? 'commit' : 'retry';
}`,
                  testCases: ['Detects stale sessions', 'Avoids double commits']
                }
              }
            ]
          },
          {
            id: `m_gen_2_${Date.now()}`,
            title: `Phase 2: Advanced Deep-Dive in ${selectedFocus[1] || 'Stateful Systems'}`,
            description: `Production-scale design patterns, high throughput optimization, and distributed peer synchronization.`,
            estimatedHours: Math.round(weeklyHours * 2),
            skillsTrained: ['eval_observability', 'distributed_systems'],
            status: 'available',
            modules: [
              {
                id: `mod_gen_201_${Date.now()}`,
                title: `Architecture Review: Real-Time Telemetry & Evals`,
                type: 'case_study',
                durationMinutes: 40,
                xpReward: 280,
                completed: false,
                summary: `Audit production case studies and evaluate against real-world compliance benchmarks.`,
                contentMarkdown: `### Telemetry Case Study
Evaluate the cost-to-latency trade-offs of streaming token generation with automated observability.`
              }
            ]
          }
        ]
      };

      setIsGenerating(false);
      onPathCreated(generatedPath);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-2xl rounded-2xl border border-slate-800 bg-slate-900 p-6 md:p-8 shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-600/30">
            <Sparkles className="h-6 w-6 text-amber-300" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">AI Adaptive Pathway Generator</h2>
            <p className="text-xs text-slate-400">
              NexusLXP synthesizes a personalized curriculum calibrated to your skill gaps and target title.
            </p>
          </div>
        </div>

        {/* Modal Body */}
        <div className="mt-6 space-y-6">
          {/* Target Role */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              1. What is your Target Career Role?
            </label>
            <div className="flex flex-wrap gap-2 mb-2">
              {PRESET_ROLES.map((role) => (
                <button
                  key={role}
                  type="button"
                  onClick={() => setTargetRole(role)}
                  className={`rounded-lg px-2.5 py-1.5 text-xs font-medium transition-all ${
                    targetRole === role
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'border border-slate-800 bg-slate-800/60 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {role}
                </button>
              ))}
            </div>
            <input
              type="text"
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
              placeholder="Or type a custom role (e.g. Principal Robotics AI Architect)"
              className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Current Experience Level & Commitment */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                2. Current Proficiency Level
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['Mid', 'Senior', 'Lead'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setCurrentLevel(lvl)}
                    className={`rounded-lg py-2 text-xs font-semibold text-center border transition-all ${
                      currentLevel === lvl
                        ? 'border-indigo-500 bg-indigo-500/20 text-indigo-300'
                        : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    {lvl} Level
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                3. Weekly Commitment: <span className="text-indigo-400">{weeklyHours} hrs/week</span>
              </label>
              <div className="pt-2">
                <input
                  type="range"
                  min="2"
                  max="15"
                  value={weeklyHours}
                  onChange={(e) => setWeeklyHours(parseInt(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
                <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                  <span>2 hrs (Paced)</span>
                  <span>6 hrs (Optimal)</span>
                  <span>15 hrs (Intensive)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Priority Focus Gaps */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              4. Select Priority Skill Focuses to Accelerate
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {focusOptions.map((item) => {
                const isSelected = selectedFocus.includes(item);
                return (
                  <button
                    key={item}
                    type="button"
                    onClick={() => toggleFocus(item)}
                    className={`flex items-center justify-between rounded-lg border px-3 py-2 text-left text-xs font-medium transition-all ${
                      isSelected
                        ? 'border-indigo-500/50 bg-indigo-950/30 text-indigo-200'
                        : 'border-slate-800 bg-slate-950/40 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <span>{item}</span>
                    {isSelected && <Check className="h-3.5 w-3.5 text-indigo-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="mt-8 flex items-center justify-between border-t border-slate-800 pt-4">
          <div className="text-xs text-slate-400 flex items-center gap-1.5">
            <Zap className="h-3.5 w-3.5 text-amber-400" />
            <span>Generates adaptive sequence with interactive checkpoints</span>
          </div>

          <button
            onClick={handleGenerate}
            disabled={isGenerating || !targetRole.trim()}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 px-5 py-2.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:from-indigo-500 hover:to-violet-500 transition-all disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                <span>Synthesizing Adaptive Path...</span>
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 text-amber-300" />
                <span>Generate Tailored Pathway</span>
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
