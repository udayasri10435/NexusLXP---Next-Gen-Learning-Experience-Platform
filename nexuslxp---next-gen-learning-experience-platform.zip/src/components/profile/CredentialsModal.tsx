import React, { useState } from 'react';
import { UserProfile } from '../../types/lxp';
import {
  X,
  Award,
  ShieldCheck,
  Share2,
  Copy,
  Check,
  Download,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CredentialsModalProps {
  user: UserProfile;
  isOpen: boolean;
  onClose: () => void;
}

export const CredentialsModal: React.FC<CredentialsModalProps> = ({
  user,
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const cert = user.certificates[0];

  const handleCopyLink = () => {
    navigator.clipboard?.writeText?.(
      `https://nexuslxp.verify/credentials/${cert?.credentialId || 'NEXUS-8849'}`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTriggerCelebrate = () => {
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.5 }
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-2xl rounded-2xl border border-slate-800 bg-slate-900 p-6 md:p-8 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
            <Award className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Verified Skill Credentials & Certificates</h2>
            <p className="text-xs text-slate-400">
              NexusLXP cryptographically verifiable certificates earned through rigorous code labs and peer reviews.
            </p>
          </div>
        </div>

        {/* Certificate Display Card */}
        {cert ? (
          <div className="mt-6 rounded-2xl border-2 border-indigo-500/40 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/60 p-8 shadow-2xl relative overflow-hidden">
            {/* Holographic accent glow */}
            <div className="absolute -top-12 -right-12 h-44 w-44 rounded-full bg-gradient-to-br from-purple-500/20 to-cyan-500/20 blur-2xl pointer-events-none" />

            <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
              <div className="flex items-center gap-2">
                <span className="text-sm font-extrabold tracking-tight text-white">
                  Nexus<span className="text-indigo-400">LXP</span>
                </span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">
                  ACCREDITED
                </span>
              </div>
              <div className="flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[11px] font-bold text-emerald-400 border border-emerald-500/20">
                <ShieldCheck className="h-3.5 w-3.5" />
                <span>Verified Credential</span>
              </div>
            </div>

            <div className="mt-6 text-center">
              <p className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
                Certificate of Technical Mastery
              </p>
              <h3 className="mt-2 text-xl font-extrabold text-white">
                {cert.title}
              </h3>
              <p className="mt-2 text-xs text-slate-300">
                Awarded to <strong className="text-indigo-300 font-bold">{user.name}</strong> for demonstrated architecture competence.
              </p>
            </div>

            {/* Verified Skills Tags */}
            <div className="mt-6 pt-4 border-t border-slate-800/80">
              <p className="text-[10px] text-slate-400 uppercase tracking-wider text-center mb-2 font-semibold">
                Competencies Benchmarked & Audited
              </p>
              <div className="flex flex-wrap justify-center gap-2">
                {cert.skillsVerified.map((sk) => (
                  <span
                    key={sk}
                    className="rounded-md bg-indigo-500/10 px-2.5 py-1 text-xs font-semibold text-indigo-300 border border-indigo-500/20"
                  >
                    ✓ {sk.replace('_', ' ').toUpperCase()}
                  </span>
                ))}
              </div>
            </div>

            {/* Seal & Metadata */}
            <div className="mt-6 flex items-center justify-between text-xs text-slate-400 pt-4 border-t border-slate-800">
              <div>
                <p className="text-[10px] text-slate-500 uppercase">Credential ID</p>
                <p className="font-mono text-[11px] text-slate-300">{cert.credentialId}</p>
              </div>

              <div>
                <p className="text-[10px] text-slate-500 uppercase">Issue Date</p>
                <p className="text-[11px] text-slate-300">{cert.issueDate}</p>
              </div>

              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-tr from-amber-400 to-amber-600 shadow-md shadow-amber-500/20 text-slate-950 font-bold text-[10px]">
                SEAL
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-6 text-center text-slate-400 py-8">
            No certificates unlocked yet. Complete your first learning path milestone to earn one!
          </div>
        )}

        {/* Action Buttons */}
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800">
          <button
            onClick={handleTriggerCelebrate}
            className="flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 font-semibold"
          >
            <Sparkles className="h-4 w-4" />
            <span>Celebrate Achievement</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyLink}
              className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700 transition-colors"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Verification Link Copied!' : 'Copy Verification Link'}</span>
            </button>

            <button
              onClick={() => {
                alert(`Downloaded verified cryptographic certificate: ${cert?.credentialId}`);
              }}
              className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-500 transition-colors"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
