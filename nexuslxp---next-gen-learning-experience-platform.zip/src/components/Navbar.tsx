import React, { useState } from 'react';
import {
  Compass,
  Network,
  Users,
  BarChart3,
  Flame,
  Zap,
  Sparkles,
  Search,
  Award,
  ChevronDown,
  Layers,
  GraduationCap
} from 'lucide-react';
import { UserProfile } from '../types/lxp';

interface NavbarProps {
  activeTab: 'paths' | 'skills' | 'social' | 'analytics';
  setActiveTab: (tab: 'paths' | 'skills' | 'social' | 'analytics') => void;
  user: UserProfile;
  onOpenGenerator: () => void;
  onOpenCredentials: () => void;
  isManagerMode: boolean;
  setIsManagerMode: (val: boolean) => void;
  searchQuery: string;
  setSearchQuery: (val: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  user,
  onOpenGenerator,
  onOpenCredentials,
  isManagerMode,
  setIsManagerMode,
  searchQuery,
  setSearchQuery,
}) => {
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand & Mode */}
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('paths')}>
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-cyan-400 p-[1px] shadow-lg shadow-indigo-500/20">
              <div className="flex h-full w-full items-center justify-center rounded-[11px] bg-slate-950">
                <Network className="h-5 w-5 text-indigo-400 animate-pulse-glow" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold tracking-tight text-white">Nexus<span className="text-indigo-400">LXP</span></span>
                <span className="rounded-md bg-indigo-500/10 px-2 py-0.5 text-[10px] font-semibold tracking-wide text-indigo-400 border border-indigo-500/20">
                  ENTERPRISE
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">Adaptive Skills & Social Learning</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => setActiveTab('paths')}
              className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold transition-all ${
                activeTab === 'paths'
                  ? 'bg-indigo-600/15 text-indigo-300 border border-indigo-500/30'
                  : 'text-slate-300 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <Compass className="h-4 w-4" />
              Learning Pathways
            </button>

            <button
              onClick={() => setActiveTab('skills')}
              className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold transition-all ${
                activeTab === 'skills'
                  ? 'bg-indigo-600/15 text-indigo-300 border border-indigo-500/30'
                  : 'text-slate-300 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <Layers className="h-4 w-4" />
              Skills Graph
            </button>

            <button
              onClick={() => setActiveTab('social')}
              className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold transition-all ${
                activeTab === 'social'
                  ? 'bg-indigo-600/15 text-indigo-300 border border-indigo-500/30'
                  : 'text-slate-300 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <Users className="h-4 w-4" />
              Social Cohorts
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold transition-all ${
                activeTab === 'analytics'
                  ? 'bg-indigo-600/15 text-indigo-300 border border-indigo-500/30'
                  : 'text-slate-300 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <BarChart3 className="h-4 w-4" />
              Team Intelligence
            </button>
          </nav>
        </div>

        {/* Global Search & Actions */}
        <div className="flex items-center gap-3">
          {/* Quick Search */}
          <div className="relative hidden lg:block w-52 xl:w-64">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search skills, paths, bytes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-lg border border-slate-800 bg-slate-900/80 py-1.5 pl-9 pr-3 text-xs text-slate-200 placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* AI Path Generator Action */}
          <button
            onClick={onOpenGenerator}
            className="hidden sm:flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-indigo-600 to-violet-600 px-3 py-1.5 text-xs font-medium text-white shadow-md shadow-indigo-600/20 hover:from-indigo-500 hover:to-violet-500 transition-all active:scale-95"
          >
            <Sparkles className="h-3.5 w-3.5 text-amber-300" />
            <span>Generate Path</span>
          </button>

          {/* Gamification Stats */}
          <div className="flex items-center gap-2 border-l border-slate-800 pl-3">
            <div className="flex items-center gap-1 rounded-md bg-amber-500/10 px-2 py-1 text-xs font-semibold text-amber-400 border border-amber-500/20" title="Active Daily Learning Streak">
              <Flame className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
              <span>{user.streakDays}d</span>
            </div>

            <div className="flex items-center gap-1 rounded-md bg-indigo-500/10 px-2 py-1 text-xs font-semibold text-indigo-400 border border-indigo-500/20" title="Experience Points">
              <Zap className="h-3.5 w-3.5 fill-indigo-400 text-indigo-400" />
              <span>{user.xp.toLocaleString()} XP</span>
            </div>
          </div>

          {/* View Mode Toggle (Learner vs L&D Lead) */}
          <button
            onClick={() => {
              setIsManagerMode(!isManagerMode);
              if (!isManagerMode) {
                setActiveTab('analytics');
              } else {
                setActiveTab('paths');
              }
            }}
            className={`hidden xl:flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-medium transition-colors ${
              isManagerMode
                ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
                : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-white'
            }`}
            title="Toggle between Learner and L&D Leader view"
          >
            <GraduationCap className="h-3.5 w-3.5" />
            <span>{isManagerMode ? 'Lead Mode' : 'Learner Mode'}</span>
          </button>

          {/* User Profile Menu */}
          <div className="relative">
            <button
              onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
              className="flex items-center gap-2 rounded-lg p-1 hover:bg-slate-800 transition-colors"
            >
              <img
                src={user.avatar}
                alt={user.name}
                className="h-8 w-8 rounded-full object-cover ring-2 ring-indigo-500/40"
              />
              <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
            </button>

            {profileDropdownOpen && (
              <div className="absolute right-0 mt-2 w-64 rounded-xl border border-slate-800 bg-slate-900/95 p-3 shadow-xl backdrop-blur-md">
                <div className="border-b border-slate-800 pb-2 mb-2">
                  <p className="text-xs font-bold text-white">{user.name}</p>
                  <p className="text-[11px] text-slate-400">{user.role}</p>
                  <p className="mt-1 text-[10px] text-indigo-400 font-medium">🎯 Target: {user.targetRole}</p>
                </div>
                <div className="space-y-1">
                  <button
                    onClick={() => {
                      onOpenCredentials();
                      setProfileDropdownOpen(false);
                    }}
                    className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white"
                  >
                    <Award className="h-3.5 w-3.5 text-amber-400" />
                    <span>My Verified Credentials ({user.certificates.length})</span>
                  </button>
                  <button
                    onClick={() => {
                      setIsManagerMode(!isManagerMode);
                      if (!isManagerMode) setActiveTab('analytics');
                      setProfileDropdownOpen(false);
                    }}
                    className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white"
                  >
                    <BarChart3 className="h-3.5 w-3.5 text-emerald-400" />
                    <span>Switch to {isManagerMode ? 'Learner View' : 'Manager / L&D View'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Navigation bar */}
      <div className="flex md:hidden border-t border-slate-800/80 px-2 py-1 bg-slate-950 justify-around">
        <button
          onClick={() => setActiveTab('paths')}
          className={`flex flex-col items-center py-1 text-[10px] font-medium ${
            activeTab === 'paths' ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Compass className="h-4 w-4" />
          <span>Pathways</span>
        </button>
        <button
          onClick={() => setActiveTab('skills')}
          className={`flex flex-col items-center py-1 text-[10px] font-medium ${
            activeTab === 'skills' ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Layers className="h-4 w-4" />
          <span>Skills</span>
        </button>
        <button
          onClick={() => setActiveTab('social')}
          className={`flex flex-col items-center py-1 text-[10px] font-medium ${
            activeTab === 'social' ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Users className="h-4 w-4" />
          <span>Cohorts</span>
        </button>
        <button
          onClick={() => setActiveTab('analytics')}
          className={`flex flex-col items-center py-1 text-[10px] font-medium ${
            activeTab === 'analytics' ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <BarChart3 className="h-4 w-4" />
          <span>Team</span>
        </button>
      </div>
    </header>
  );
};
