/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { PathRoadmap } from './components/paths/PathRoadmap';
import { PathGeneratorModal } from './components/paths/PathGeneratorModal';
import { SkillsGraph } from './components/skills/SkillsGraph';
import { SkillDiagnosticModal } from './components/skills/SkillDiagnosticModal';
import { SocialHub } from './components/social/SocialHub';
import { ModulePlayerModal } from './components/player/ModulePlayerModal';
import { EnterpriseAnalytics } from './components/analytics/EnterpriseAnalytics';
import { CredentialsModal } from './components/profile/CredentialsModal';

import {
  INITIAL_SKILLS,
  INITIAL_PATHS,
  INITIAL_PEER_BYTES,
  INITIAL_COHORTS,
  INITIAL_PEER_REVIEWS,
  INITIAL_DISCUSSIONS,
  INITIAL_USER_PROFILE,
  INITIAL_TEAM_STATS,
} from './data/mockLxpData';

import {
  SkillNode,
  LearningPath,
  LearningModule,
  Milestone,
  CohortPod,
  PeerByte,
  PeerReviewSubmission,
  DiscussionThread,
  UserProfile,
  TeamMemberSkillStat,
} from './types/lxp';

export default function App() {
  // Navigation & View Mode
  const [activeTab, setActiveTab] = useState<'paths' | 'skills' | 'social' | 'analytics'>('paths');
  const [isManagerMode, setIsManagerMode] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Primary Platform State
  const [user, setUser] = useState<UserProfile>(INITIAL_USER_PROFILE);
  const [skills, setSkills] = useState<SkillNode[]>(INITIAL_SKILLS);
  const [paths, setPaths] = useState<LearningPath[]>(INITIAL_PATHS);
  const [currentPath, setCurrentPath] = useState<LearningPath>(INITIAL_PATHS[0]);
  const [cohorts, setCohorts] = useState<CohortPod[]>(INITIAL_COHORTS);
  const [peerBytes, setPeerBytes] = useState<PeerByte[]>(INITIAL_PEER_BYTES);
  const [peerReviews, setPeerReviews] = useState<PeerReviewSubmission[]>(INITIAL_PEER_REVIEWS);
  const [discussions, setDiscussions] = useState<DiscussionThread[]>(INITIAL_DISCUSSIONS);
  const [teamStats, setTeamStats] = useState<TeamMemberSkillStat[]>(INITIAL_TEAM_STATS);

  // Modals & Active Drawers
  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);
  const [isCredentialsOpen, setIsCredentialsOpen] = useState(false);
  const [diagnosticSkill, setDiagnosticSkill] = useState<SkillNode | null>(null);

  // Active module player
  const [playerModule, setPlayerModule] = useState<LearningModule | null>(null);
  const [playerMilestone, setPlayerMilestone] = useState<Milestone | null>(null);

  // Handlers for Module Player
  const handleOpenModule = (module: LearningModule, milestone: Milestone) => {
    setPlayerModule(module);
    setPlayerMilestone(milestone);
  };

  const handleCloseModule = () => {
    setPlayerModule(null);
    setPlayerMilestone(null);
  };

  const handleCompleteModule = (moduleId: string, earnedXp: number) => {
    // 1. Update module in currentPath and all paths
    const updatedPaths = paths.map((path) => {
      const updatedMilestones = path.milestones.map((m) => {
        const updatedModules = m.modules.map((mod) => {
          if (mod.id === moduleId) {
            return { ...mod, completed: true };
          }
          return mod;
        });

        // If all modules completed in this milestone, mark milestone completed and unlock next
        const allCompleted = updatedModules.length > 0 && updatedModules.every((mod) => mod.completed);
        return {
          ...m,
          modules: updatedModules,
          status: allCompleted ? ('completed' as const) : m.status,
        };
      });

      // Unlock next available milestone
      for (let i = 0; i < updatedMilestones.length - 1; i++) {
        if (updatedMilestones[i].status === 'completed' && updatedMilestones[i + 1].status === 'locked') {
          updatedMilestones[i + 1].status = 'available';
        }
      }

      return {
        ...path,
        milestones: updatedMilestones,
      };
    });

    setPaths(updatedPaths);
    const active = updatedPaths.find((p) => p.id === currentPath.id) || updatedPaths[0];
    setCurrentPath(active);

    // 2. Award XP to User Profile
    setUser((prev) => ({
      ...prev,
      xp: prev.xp + earnedXp,
      hoursSpent: Math.round((prev.hoursSpent + 0.5) * 10) / 10,
    }));
  };

  // Handler for custom generated path
  const handlePathCreated = (newPath: LearningPath) => {
    setPaths([newPath, ...paths]);
    setCurrentPath(newPath);
    setActiveTab('paths');
  };

  // Handler for Skill Diagnostic Level Up
  const handleLevelUpSkill = (skillId: string, newLevel: number, earnedXp: number) => {
    setSkills((prev) =>
      prev.map((s) => {
        if (s.id === skillId) {
          return {
            ...s,
            level: newLevel as any,
            endorsements: s.endorsements + 1,
            recentActivity: `Passed Level ${newLevel} Diagnostic Assessment (+${earnedXp} XP)`,
          };
        }
        return s;
      })
    );

    // Award XP
    setUser((prev) => ({
      ...prev,
      xp: prev.xp + earnedXp,
    }));
  };

  // Handler for Social Cohort Join/Leave
  const handleToggleCohortJoin = (cohortId: string) => {
    setCohorts((prev) =>
      prev.map((c) => {
        if (c.id === cohortId) {
          const joined = !c.joined;
          return {
            ...c,
            joined,
            activeLearners: joined ? c.activeLearners + 1 : c.activeLearners - 1,
          };
        }
        return c;
      })
    );
  };

  // Handler for Byte Likes
  const handleLikeByte = (byteId: string) => {
    setPeerBytes((prev) =>
      prev.map((b) => {
        if (b.id === byteId) {
          const hasLiked = !b.hasLiked;
          return {
            ...b,
            hasLiked,
            likes: hasLiked ? b.likes + 1 : b.likes - 1,
          };
        }
        return b;
      })
    );
  };

  // Handler for Adding a Byte
  const handleAddByte = (title: string, snippet: string, tag: string) => {
    const newByte: PeerByte = {
      id: `byte_${Date.now()}`,
      author: {
        name: user.name,
        role: user.role,
        avatar: user.avatar,
        badge: 'Contributor',
      },
      title,
      snippet,
      tags: [tag],
      likes: 1,
      hasLiked: true,
      commentsCount: 0,
      timestamp: 'Just now',
    };
    setPeerBytes([newByte, ...peerBytes]);
    setUser((prev) => ({ ...prev, xp: prev.xp + 50 }));
  };

  // Handler for Peer Review Feedback
  const handleSubmitReviewFeedback = (reviewId: string, feedback: string) => {
    setPeerReviews((prev) =>
      prev.map((pr) => {
        if (pr.id === reviewId) {
          return {
            ...pr,
            reviewsCount: pr.reviewsCount + 1,
            status: 'reviewed',
            rubricScore: 94,
          };
        }
        return pr;
      })
    );
    setUser((prev) => ({ ...prev, xp: prev.xp + 150 }));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        user={user}
        onOpenGenerator={() => setIsGeneratorOpen(true)}
        onOpenCredentials={() => setIsCredentialsOpen(true)}
        isManagerMode={isManagerMode}
        setIsManagerMode={setIsManagerMode}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {/* Main App Content Body */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-6 md:py-8">
        {activeTab === 'paths' && (
          <PathRoadmap
            currentPath={currentPath}
            allPaths={paths}
            onSelectPath={setCurrentPath}
            onOpenModule={handleOpenModule}
            skills={skills}
            onOpenGenerator={() => setIsGeneratorOpen(true)}
            onOpenCredentials={() => setIsCredentialsOpen(true)}
          />
        )}

        {activeTab === 'skills' && (
          <SkillsGraph
            skills={skills}
            onSelectSkillForDiagnostic={(skill) => setDiagnosticSkill(skill)}
            targetRole={user.targetRole}
          />
        )}

        {activeTab === 'social' && (
          <SocialHub
            cohorts={cohorts}
            peerBytes={peerBytes}
            peerReviews={peerReviews}
            discussions={discussions}
            onToggleCohortJoin={handleToggleCohortJoin}
            onLikeByte={handleLikeByte}
            onAddByte={handleAddByte}
            onSubmitReviewFeedback={handleSubmitReviewFeedback}
          />
        )}

        {activeTab === 'analytics' && (
          <EnterpriseAnalytics
            teamStats={teamStats}
            skills={skills}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <div className="mx-auto max-w-7xl px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">NexusLXP</span>
            <span>— The Modern Successor to Legacy LMS</span>
          </div>
          <div>
            <span>Personalized Pathways • Dynamic Skills Ontology • Peer Social Cohorts</span>
          </div>
        </div>
      </footer>

      {/* Modals & Dialogs */}
      <PathGeneratorModal
        isOpen={isGeneratorOpen}
        onClose={() => setIsGeneratorOpen(false)}
        onPathCreated={handlePathCreated}
      />

      <CredentialsModal
        user={user}
        isOpen={isCredentialsOpen}
        onClose={() => setIsCredentialsOpen(false)}
      />

      <SkillDiagnosticModal
        skill={diagnosticSkill}
        isOpen={!!diagnosticSkill}
        onClose={() => setDiagnosticSkill(null)}
        onLevelUp={handleLevelUpSkill}
      />

      <ModulePlayerModal
        module={playerModule}
        milestone={playerMilestone}
        isOpen={!!playerModule}
        onClose={handleCloseModule}
        onCompleteModule={handleCompleteModule}
      />
    </div>
  );
}
