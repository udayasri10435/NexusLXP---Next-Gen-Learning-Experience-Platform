export type SkillCategory = 'ai_ml' | 'systems_cloud' | 'frontend_dev' | 'product_leadership' | 'security_data';

export type SkillLevel = 1 | 2 | 3 | 4 | 5; // 1: Novice, 2: Competent, 3: Proficient, 4: Advanced, 5: Master

export interface SkillNode {
  id: string;
  name: string;
  category: SkillCategory;
  level: SkillLevel;
  targetLevel: SkillLevel;
  experiencePoints: number;
  maxPoints: number;
  connections: string[]; // skill IDs connected in graph
  description: string;
  endorsements: number;
  recentActivity?: string;
  x?: number;
  y?: number;
}

export type ModuleType = 'video' | 'interactive_lab' | 'case_study' | 'peer_review' | 'quiz';

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface LearningModule {
  id: string;
  title: string;
  type: ModuleType;
  durationMinutes: number;
  xpReward: number;
  completed: boolean;
  summary: string;
  videoUrl?: string;
  contentMarkdown: string;
  interactiveChallenge?: {
    instruction: string;
    starterCode?: string;
    sampleSolution?: string;
    testCases?: string[];
  };
  quiz?: QuizQuestion[];
  resources?: { title: string; url: string; type: 'doc' | 'github' | 'paper' }[];
}

export interface Milestone {
  id: string;
  title: string;
  description: string;
  estimatedHours: number;
  skillsTrained: string[]; // skill IDs
  modules: LearningModule[];
  status: 'locked' | 'available' | 'in_progress' | 'completed';
}

export interface LearningPath {
  id: string;
  title: string;
  roleTarget: string;
  description: string;
  category: SkillCategory;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Executive';
  totalDurationHours: number;
  enrolledLearnersCount: number;
  rating: number;
  skillsCovered: string[];
  milestones: Milestone[];
  isCustomGenerated?: boolean;
}

export interface PeerByte {
  id: string;
  author: {
    name: string;
    role: string;
    avatar: string;
    badge: string;
  };
  title: string;
  snippet: string;
  tags: string[];
  likes: number;
  hasLiked?: boolean;
  commentsCount: number;
  timestamp: string;
  relatedSkillId?: string;
}

export interface CohortPod {
  id: string;
  name: string;
  topic: string;
  currentMilestone: string;
  activeLearners: number;
  maxCapacity: number;
  nextSyncDate: string;
  facilitator: {
    name: string;
    role: string;
    avatar: string;
  };
  memberAvatars: string[];
  joined?: boolean;
}

export interface PeerReviewSubmission {
  id: string;
  studentName: string;
  studentAvatar: string;
  projectTitle: string;
  pathName: string;
  submittedAt: string;
  repoOrDocUrl: string;
  description: string;
  reviewsCount: number;
  reviewsNeeded: number;
  status: 'needs_review' | 'reviewed';
  rubricScore?: number;
}

export interface DiscussionThread {
  id: string;
  author: {
    name: string;
    avatar: string;
    role: string;
  };
  title: string;
  body: string;
  category: string;
  upvotes: number;
  hasUpvoted?: boolean;
  replies: {
    id: string;
    author: { name: string; avatar: string; role: string };
    content: string;
    timestamp: string;
    isAcceptedSolution?: boolean;
  }[];
  timestamp: string;
}

export interface UserProfile {
  id: string;
  name: string;
  role: string;
  targetRole: string;
  company: string;
  avatar: string;
  xp: number;
  streakDays: number;
  completedPathsCount: number;
  hoursSpent: number;
  certificates: {
    id: string;
    pathId: string;
    title: string;
    issueDate: string;
    credentialId: string;
    skillsVerified: string[];
  }[];
}

export interface TeamMemberSkillStat {
  id: string;
  name: string;
  role: string;
  avatar: string;
  targetRole: string;
  readinessPercentage: number;
  topSkills: { name: string; level: number }[];
  weeklyHours: number;
  status: 'ahead' | 'on_track' | 'needs_attention';
}
